-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (i486)
--
-- Host: int-mysql-master.gizurcloud.com    Database: testlink
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.7-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assignment_status`
--

DROP TABLE IF EXISTS `assignment_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment_status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_status`
--

LOCK TABLES `assignment_status` WRITE;
/*!40000 ALTER TABLE `assignment_status` DISABLE KEYS */;
INSERT INTO `assignment_status` VALUES (1,'open'),(2,'closed'),(3,'completed'),(4,'todo_urgent'),(5,'todo');
/*!40000 ALTER TABLE `assignment_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_types`
--

DROP TABLE IF EXISTS `assignment_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_table` varchar(30) DEFAULT '',
  `description` varchar(100) NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_types`
--

LOCK TABLES `assignment_types` WRITE;
/*!40000 ALTER TABLE `assignment_types` DISABLE KEYS */;
INSERT INTO `assignment_types` VALUES (1,'testplan_tcversions','testcase_execution'),(2,'tcversions','testcase_review');
/*!40000 ALTER TABLE `assignment_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachments`
--

DROP TABLE IF EXISTS `attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attachments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fk_table` varchar(250) DEFAULT '',
  `title` varchar(250) DEFAULT '',
  `description` varchar(250) DEFAULT '',
  `file_name` varchar(250) NOT NULL DEFAULT '',
  `file_path` varchar(250) DEFAULT '',
  `file_size` int(11) NOT NULL DEFAULT '0',
  `file_type` varchar(250) NOT NULL DEFAULT '',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `content` longblob,
  `compression_type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachments`
--

LOCK TABLES `attachments` WRITE;
/*!40000 ALTER TABLE `attachments` DISABLE KEYS */;
INSERT INTO `attachments` VALUES (1,43,'executions','Before Call-Offs by 10','','Screenshot from 2012-12-13 16:17:11.png','executions/43/406dce86356833f29a56dd8e752fc662.png',71413,'image/png','2012-12-13 11:48:08',NULL,1),(2,43,'executions','After Call-Offs by 10','','Screenshot from 2012-12-13 16:18:32.png','executions/43/eda78f317af712fe3bb83476da029cf3.png',71601,'image/png','2012-12-13 11:48:48',NULL,1),(3,43,'executions','After Call-Offs by 10 result at vTiger','','Screenshot from 2012-12-13 16:22:46.png','executions/43/193fa63698448da6adf72be78f41cc75.png',143744,'image/png','2012-12-13 11:53:22',NULL,1),(4,44,'executions','Before Increasing product by 10','','Screenshot from 2012-12-13 16:46:08.png','executions/44/4822ee2bfc01e78afdcd85c18ef7975a.png',137549,'image/png','2012-12-13 12:16:56',NULL,1),(7,44,'executions','After Increaing the product by 10, result at Biker Portal','','Screenshot from 2012-12-13 16:47:24.png','executions/44/0c294d1f48f886e59d1cd678734ebff2.png',90673,'image/png','2012-12-13 12:19:56',NULL,1),(8,44,'executions','After Increaing the product by 10, result at vTiger','','Screenshot from 2012-12-13 16:47:37.png','executions/44/4feb217d8a4aaa571acf7c72992765c8.png',141742,'image/png','2012-12-13 12:20:16',NULL,1),(9,45,'executions','Before excution list of openned ticket in vTiger','','Screenshot from 2012-12-13 17:01:54.png','executions/45/125f499a3e70d81c0f6d97bd9eeab927.png',144432,'image/png','2012-12-13 12:34:07',NULL,1),(11,45,'executions','After excution list of tickets in vTiger','','Screenshot from 2012-12-13 17:02:08.png','executions/45/58a1ee822eac40c256708b5a8759015c.png',148890,'image/png','2012-12-13 12:35:40',NULL,1),(12,45,'executions','After excution result at biker portal','','Screenshot from 2012-12-13 17:02:16.png','executions/45/edf49ee2df9bea823d517fbb2a943d82.png',91177,'image/png','2012-12-13 12:36:04',NULL,1),(13,46,'executions','Before excution list of tickets in vTiger','','Screenshot from 2012-12-14 10:41:06.png','executions/46/e5c0db3896a47a78bca7666780c16771.png',153669,'image/png','2012-12-14 06:19:00',NULL,1),(14,46,'executions','After excution list of tickets in vTiger','','Screenshot from 2012-12-14 10:42:17.png','executions/46/c863626c27f8f8ce804dd5409515af47.png',158371,'image/png','2012-12-14 06:19:20',NULL,1),(15,47,'executions','Before excution list of tickets in vTiger','','Screenshot from 2012-12-14 10:42:17.png','executions/47/edd4815f3274a7a39656cc825eca0a1f.png',158371,'image/png','2012-12-14 06:32:34',NULL,1),(16,47,'executions','After excution list of tickets in vTiger','','Screenshot from 2012-12-14 11:02:03.png','executions/47/157f219ceec559abe6377c40443aef25.png',176271,'image/png','2012-12-14 06:32:53',NULL,1),(17,48,'executions','Before excution list of tickets in vTiger','','Screenshot from 2012-12-14 11:30:11.png','executions/48/4655d1961c57901782e72b1e8ab48b7b.png',162179,'image/png','2012-12-14 07:03:11',NULL,1),(18,48,'executions','After excution list of tickets in vTiger','','Screenshot from 2012-12-14 11:32:22.png','executions/48/553c549a4fc3a28b593c2557059072a5.png',180769,'image/png','2012-12-14 07:03:26',NULL,1),(19,49,'executions','Before excution list of tickets in vTiger','','Screenshot from 2012-12-14 11:42:59.png','executions/49/3e6ba31ebb5db291b85099997e50b6e9.png',151055,'image/png','2012-12-14 07:17:13',NULL,1),(20,49,'executions','After excution list of tickets in vTiger','','Screenshot from 2012-12-14 11:46:46.png','executions/49/daef2b4ec4481319943a7a314db6068d.png',162307,'image/png','2012-12-14 07:17:29',NULL,1);
/*!40000 ALTER TABLE `attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `builds`
--

DROP TABLE IF EXISTS `builds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `builds` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT 'undefined',
  `notes` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_open` tinyint(1) NOT NULL DEFAULT '1',
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `release_date` date DEFAULT NULL,
  `closed_on_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`testplan_id`,`name`),
  KEY `testplan_id` (`testplan_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='Available builds';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `builds`
--

LOCK TABLES `builds` WRITE;
/*!40000 ALTER TABLE `builds` DISABLE KEYS */;
INSERT INTO `builds` VALUES (1,7,'A first release','<p>&nbsp;Thisis a first release</p>',1,1,NULL,'2012-03-06 10:20:20',NULL,NULL),(2,10,'March - test issue 46','',1,1,NULL,'2012-03-06 10:44:50','2012-03-11',NULL),(3,10,'Release for Sales Order screen','',1,1,NULL,'2012-03-19 16:41:49','2012-04-05',NULL),(6,40,'Release/Build for Sales Order screen','',1,1,NULL,'2012-03-23 07:47:41','2012-04-02',NULL),(7,100,'Test in development environment','',1,1,NULL,'2012-05-11 11:43:13','2012-05-11',NULL),(8,498,'Damage claim 1.0','<p>entire app</p>',1,1,NULL,'2012-10-01 10:00:41',NULL,NULL),(9,502,'Damage claim 1.0','<p>entire app</p>',1,1,NULL,'2012-10-03 08:03:00',NULL,NULL),(10,539,'Testing Quote and Sales Order module and seeing the result at biker portal.','',1,1,NULL,'2012-12-13 10:27:19','2012-12-13',NULL);
/*!40000 ALTER TABLE `builds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_design_values`
--

DROP TABLE IF EXISTS `cfield_design_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfield_design_values` (
  `field_id` int(10) NOT NULL DEFAULT '0',
  `node_id` int(10) NOT NULL DEFAULT '0',
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`node_id`),
  KEY `idx_cfield_design_values` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_design_values`
--

LOCK TABLES `cfield_design_values` WRITE;
/*!40000 ALTER TABLE `cfield_design_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_design_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_execution_values`
--

DROP TABLE IF EXISTS `cfield_execution_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfield_execution_values` (
  `field_id` int(10) NOT NULL DEFAULT '0',
  `execution_id` int(10) NOT NULL DEFAULT '0',
  `testplan_id` int(10) NOT NULL DEFAULT '0',
  `tcversion_id` int(10) NOT NULL DEFAULT '0',
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`execution_id`,`testplan_id`,`tcversion_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_execution_values`
--

LOCK TABLES `cfield_execution_values` WRITE;
/*!40000 ALTER TABLE `cfield_execution_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_execution_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_node_types`
--

DROP TABLE IF EXISTS `cfield_node_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfield_node_types` (
  `field_id` int(10) NOT NULL DEFAULT '0',
  `node_type_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_id`,`node_type_id`),
  KEY `idx_custom_fields_assign` (`node_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_node_types`
--

LOCK TABLES `cfield_node_types` WRITE;
/*!40000 ALTER TABLE `cfield_node_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_node_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_testplan_design_values`
--

DROP TABLE IF EXISTS `cfield_testplan_design_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfield_testplan_design_values` (
  `field_id` int(10) NOT NULL DEFAULT '0',
  `link_id` int(10) NOT NULL DEFAULT '0' COMMENT 'point to testplan_tcversion id',
  `value` varchar(4000) NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`,`link_id`),
  KEY `idx_cfield_tplan_design_val` (`link_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_testplan_design_values`
--

LOCK TABLES `cfield_testplan_design_values` WRITE;
/*!40000 ALTER TABLE `cfield_testplan_design_values` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_testplan_design_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cfield_testprojects`
--

DROP TABLE IF EXISTS `cfield_testprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cfield_testprojects` (
  `field_id` int(10) unsigned NOT NULL DEFAULT '0',
  `testproject_id` int(10) unsigned NOT NULL DEFAULT '0',
  `display_order` smallint(5) unsigned NOT NULL DEFAULT '1',
  `location` smallint(5) unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `required_on_design` tinyint(1) NOT NULL DEFAULT '0',
  `required_on_execution` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_id`,`testproject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cfield_testprojects`
--

LOCK TABLES `cfield_testprojects` WRITE;
/*!40000 ALTER TABLE `cfield_testprojects` DISABLE KEYS */;
/*!40000 ALTER TABLE `cfield_testprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `label` varchar(64) NOT NULL DEFAULT '' COMMENT 'label to display on user interface',
  `type` smallint(6) NOT NULL DEFAULT '0',
  `possible_values` varchar(4000) NOT NULL DEFAULT '',
  `default_value` varchar(4000) NOT NULL DEFAULT '',
  `valid_regexp` varchar(255) NOT NULL DEFAULT '',
  `length_min` int(10) NOT NULL DEFAULT '0',
  `length_max` int(10) NOT NULL DEFAULT '0',
  `show_on_design` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1=> show it during specification design',
  `enable_on_design` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1=> user can write/manage it during specification design',
  `show_on_execution` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1=> show it during test case execution',
  `enable_on_execution` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '1=> user can write/manage it during test case execution',
  `show_on_testplan_design` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `enable_on_testplan_design` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_custom_fields_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_version`
--

DROP TABLE IF EXISTS `db_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_version` (
  `version` varchar(50) NOT NULL DEFAULT 'unknown',
  `upgrade_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notes` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_version`
--

LOCK TABLES `db_version` WRITE;
/*!40000 ALTER TABLE `db_version` DISABLE KEYS */;
INSERT INTO `db_version` VALUES ('DB 1.4','2012-03-06 09:53:11','TestLink 1.9.1');
/*!40000 ALTER TABLE `db_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL DEFAULT '0',
  `log_level` smallint(5) unsigned NOT NULL DEFAULT '0',
  `source` varchar(45) DEFAULT NULL,
  `description` text NOT NULL,
  `fired_at` int(10) unsigned NOT NULL DEFAULT '0',
  `activity` varchar(45) DEFAULT NULL,
  `object_id` int(10) unsigned DEFAULT NULL,
  `object_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_id` (`transaction_id`),
  KEY `fired_at` (`fired_at`)
) ENGINE=MyISAM AUTO_INCREMENT=2832 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (2728,448,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:5:\"jonas\";i:1;s:13:\"62.80.198.242\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1354869734,'LOGIN',2,'users'),(2729,449,2,'GUI','E_NOTICE\nUndefined variable: cf_current_version - in /var/www/html/testlink/lib/functions/testcase.class.php - Line 967',1354869764,'PHP',NULL,NULL),(2730,449,2,'GUI','E_NOTICE\nUndefined variable: cf_other_versions - in /var/www/html/testlink/lib/functions/testcase.class.php - Line 968',1354869764,'PHP',NULL,NULL),(2731,450,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355221675,'LOGIN',7,'users'),(2732,451,2,'GUI','E_NOTICE\nUndefined index: checked_hide_inactive_users - in /var/www/html/testlink/gui/templates_c/%%F8^F85^F85A18E7%%usersAssign.tpl.php - Line 189',1355221993,'PHP',NULL,NULL),(2733,452,2,'GUI','E_NOTICE\nUndefined index: checked_hide_inactive_users - in /var/www/html/testlink/gui/templates_c/%%F8^F85^F85A18E7%%usersAssign.tpl.php - Line 189',1355221999,'PHP',NULL,NULL),(2734,453,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:17:\"audit_user_logout\";s:6:\"params\";a:1:{i:0;s:17:\"gizur-ess-prabhat\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355223160,'LOGOUT',7,'users'),(2735,454,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355224280,'LOGIN',7,'users'),(2736,455,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355286070,'LOGIN',7,'users'),(2737,456,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:6:\"ashish\";i:1;s:14:\"120.59.100.113\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355310634,'LOGIN',4,'users'),(2738,457,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:17:\"audit_user_logout\";s:6:\"params\";a:1:{i:0;s:6:\"ashish\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355311441,'LOGOUT',4,'users'),(2739,458,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355374783,'LOGIN',7,'users'),(2740,459,2,'GUI','E_NOTICE\nUndefined property: stdClass::$main_descr - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 15',1355378996,'PHP',NULL,NULL),(2741,459,2,'GUI','E_NOTICE\nUndefined property: stdClass::$sqlResult - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 20',1355378996,'PHP',NULL,NULL),(2742,459,2,'GUI','E_NOTICE\nUndefined property: stdClass::$action - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 20',1355378996,'PHP',NULL,NULL),(2743,459,2,'GUI','E_NOTICE\nUndefined property: stdClass::$sqlResult - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 25',1355378996,'PHP',NULL,NULL),(2744,460,2,'GUI','string \'print_testcase\' is not localized for locale \'en_GB\'',1355381503,'LOCALIZATION',NULL,NULL),(2745,461,2,'GUI','string \'print_testcase\' is not localized for locale \'en_GB\'',1355382518,'LOCALIZATION',NULL,NULL),(2746,462,2,'GUI','string \'print_testcase\' is not localized for locale \'en_GB\'',1355382570,'LOCALIZATION',NULL,NULL),(2747,463,2,'GUI','string \'print_testcase\' is not localized for locale \'en_GB\'',1355382589,'LOCALIZATION',NULL,NULL),(2748,464,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:13:\"182.73.67.110\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355386409,'LOGIN',7,'users'),(2749,465,2,'GUI','E_NOTICE\nUndefined property: stdClass::$main_descr - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 15',1355386542,'PHP',NULL,NULL),(2750,465,2,'GUI','E_NOTICE\nUndefined property: stdClass::$sqlResult - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 20',1355386542,'PHP',NULL,NULL),(2751,465,2,'GUI','E_NOTICE\nUndefined property: stdClass::$action - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 20',1355386542,'PHP',NULL,NULL),(2752,465,2,'GUI','E_NOTICE\nUndefined property: stdClass::$sqlResult - in /var/www/html/testlink/gui/templates_c/%%F4^F42^F42AF5F6%%tcDelete.tpl.php - Line 25',1355386542,'PHP',NULL,NULL),(2753,466,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:22:\"audit_testplan_created\";s:6:\"params\";a:2:{i:0;s:20:\"Cikab Nonfood season\";i:1;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355386744,'CREATED',539,'testplans'),(2754,467,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:29:\"CIKABNFS-9 : Create Quotation\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355387997,'ASSIGN',539,'testplans'),(2755,468,2,'GUI','E_NOTICE\nUndefined property: stdClass::$page_title - in /var/www/html/testlink/gui/templates_c/%%B6^B6A^B6AD6561%%containerView.tpl.php - Line 45',1355388092,'PHP',NULL,NULL),(2756,468,2,'GUI','E_NOTICE\nUndefined property: stdClass::$btn_reorder_testcases - in /var/www/html/testlink/gui/templates_c/%%B6^B6A^B6AD6561%%containerView.tpl.php - Line 208',1355388092,'PHP',NULL,NULL),(2757,468,2,'GUI','E_NOTICE\nUndefined property: stdClass::$btn_reorder_testcases - in /var/www/html/testlink/gui/templates_c/%%B6^B6A^B6AD6561%%containerView.tpl.php - Line 210',1355388092,'PHP',NULL,NULL),(2758,469,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:32:\"CIKABNFS-10 : Create Sales Order\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355390708,'ASSIGN',539,'testplans'),(2759,469,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355390708,'PHP',NULL,NULL),(2760,470,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:19:\"audit_build_created\";s:6:\"params\";a:3:{i:0;s:20:\"Cikab Nonfood season\";i:1;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";i:2;s:75:\"Testing Quote and Sales Order module and seeing the result at biker portal.\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355390839,'CREATE',10,'builds'),(2761,471,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355390900,'PHP',NULL,NULL),(2762,472,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355390915,'PHP',NULL,NULL),(2763,473,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:58:\"CIKABNFS-11 : Create Sales Order Call-Offs at biker portal\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355395248,'ASSIGN',539,'testplans'),(2764,473,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355395248,'PHP',NULL,NULL),(2765,474,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355395442,'PHP',NULL,NULL),(2766,475,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:22:\"Before Call-Offs by 10\";i:1;s:39:\"Screenshot from 2012-12-13 16:17:11.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355395688,'CREATE',43,'attachments'),(2767,476,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:21:\"After Call-Offs by 10\";i:1;s:39:\"Screenshot from 2012-12-13 16:18:32.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355395728,'CREATE',43,'attachments'),(2768,477,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:38:\"After Call-Offs by 10 result at vTiger\";i:1;s:39:\"Screenshot from 2012-12-13 16:22:46.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355396002,'CREATE',43,'attachments'),(2769,478,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:46:\"CIKABNFS-12 : Increase product quantity by 10.\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397294,'ASSIGN',539,'testplans'),(2770,478,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355397294,'PHP',NULL,NULL),(2771,479,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355397388,'PHP',NULL,NULL),(2772,480,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:31:\"Before Increasing product by 10\";i:1;s:39:\"Screenshot from 2012-12-13 16:46:08.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397416,'CREATE',44,'attachments'),(2777,485,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:57:\"After Increaing the product by 10, result at Biker Portal\";i:1;s:39:\"Screenshot from 2012-12-13 16:47:24.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397596,'CREATE',44,'attachments'),(2778,486,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:51:\"After Increaing the product by 10, result at vTiger\";i:1;s:39:\"Screenshot from 2012-12-13 16:47:37.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397616,'CREATE',44,'attachments'),(2779,487,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:46:\"CIKABNFS-13 : Decrease product quantity by 10.\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355398004,'ASSIGN',539,'testplans'),(2780,487,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355398004,'PHP',NULL,NULL),(2781,488,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355398398,'PHP',NULL,NULL),(2782,489,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:48:\"Before excution list of openned ticket in vTiger\";i:1;s:39:\"Screenshot from 2012-12-13 17:01:54.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355398447,'CREATE',45,'attachments'),(2783,490,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:47:\"After excution list of openned ticket in vTiger\";i:1;s:39:\"Screenshot from 2012-12-13 17:02:08.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355398468,'CREATE',45,'attachments'),(2784,491,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_deleted\";s:6:\"params\";a:1:{i:0;s:47:\"After excution list of openned ticket in vTiger\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355398514,'DELETE',10,'attachments'),(2785,492,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:40:\"After excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-13 17:02:08.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355398540,'CREATE',45,'attachments'),(2786,493,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:37:\"After excution result at biker portal\";i:1;s:39:\"Screenshot from 2012-12-13 17:02:16.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355398564,'CREATE',45,'attachments'),(2787,494,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355461945,'LOGIN',7,'users'),(2788,495,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:45:\"CIKABNFS-14 : Decrease product quantity by 30\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355462243,'ASSIGN',539,'testplans'),(2789,495,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355462244,'PHP',NULL,NULL),(2790,496,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355462307,'PHP',NULL,NULL),(2791,497,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:41:\"Before excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 10:41:06.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355462340,'CREATE',46,'attachments'),(2792,498,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:40:\"After excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 10:42:17.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355462360,'CREATE',46,'attachments'),(2793,499,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:45:\"CIKABNFS-15 : Increase product quantity by 50\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355463054,'ASSIGN',539,'testplans'),(2794,499,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355463054,'PHP',NULL,NULL),(2774,482,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:43:\"After Increaing the product by 10 at vTiger\";i:1;s:39:\"Screenshot from 2012-12-13 16:47:37.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397517,'CREATE',44,'attachments'),(2775,483,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_deleted\";s:6:\"params\";a:1:{i:0;s:43:\"After Increaing the product by 10 at vTiger\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397558,'DELETE',6,'attachments'),(2776,484,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_deleted\";s:6:\"params\";a:1:{i:0;s:49:\"After Increaing the product by 10 at Biker Portal\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397567,'DELETE',5,'attachments'),(2821,524,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:12:\"14.98.76.131\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355938421,'LOGIN',7,'users'),(2825,528,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:12:\"203.92.33.67\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1356004178,'LOGIN',7,'users'),(2824,527,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:12:\"203.92.33.67\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355998566,'LOGIN',7,'users'),(2773,481,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:49:\"After Increaing the product by 10 at Biker Portal\";i:1;s:39:\"Screenshot from 2012-12-13 16:47:24.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355397498,'CREATE',44,'attachments'),(2831,533,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:5:\"jonas\";i:1;s:11:\"62.80.223.2\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1356081014,'LOGIN',2,'users'),(2829,531,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:17:\"audit_user_logout\";s:6:\"params\";a:1:{i:0;s:17:\"gizur-ess-prabhat\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1356004251,'LOGOUT',7,'users'),(2830,532,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1356075944,'LOGIN',7,'users'),(2828,530,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1356004241,'PHP',NULL,NULL),(2827,529,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1356004218,'PHP',NULL,NULL),(2826,529,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:67:\"CIKABNFS-18 : Automate maching between realese and increase ticket.\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1356004218,'ASSIGN',539,'testplans'),(2823,526,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:12:\"203.92.33.67\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355984509,'LOGIN',7,'users'),(2820,523,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:12:\"203.92.33.67\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355897097,'LOGIN',7,'users'),(2822,525,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:17:\"audit_user_logout\";s:6:\"params\";a:1:{i:0;s:17:\"gizur-ess-prabhat\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355939801,'LOGOUT',7,'users'),(2819,522,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355479402,'LOGIN',7,'users'),(2818,521,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:5:\"jonas\";i:1;s:11:\"62.80.223.2\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355475491,'LOGIN',2,'users'),(2817,520,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:14:\"122.160.150.82\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355475020,'LOGIN',7,'users'),(2816,519,2,'GUI','E_WARNING\nfopen(/var/www/html/testlink/upload_area//executions/44/4feb217d8a4aaa571acf7c72992765c8.png): failed to open stream: No such file or directory - in /var/www/html/testlink/lib/functions/files.inc.php - Line 57',1355474889,'PHP',NULL,NULL),(2814,517,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:18:\"audit_login_failed\";s:6:\"params\";a:2:{i:0;s:5:\"jonas\";i:1;s:11:\"62.80.223.2\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355474849,'LOGIN_FAILED',2,'users'),(2815,518,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:5:\"jonas\";i:1;s:11:\"62.80.223.2\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355474858,'LOGIN',2,'users'),(2813,516,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:17:\"gizur-ess-prabhat\";i:1;s:13:\"182.73.67.110\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355472772,'LOGIN',7,'users'),(2812,515,2,'GUI','E_WARNING\nfopen(/var/www/html/testlink/upload_area//executions/45/edf49ee2df9bea823d517fbb2a943d82.png): failed to open stream: No such file or directory - in /var/www/html/testlink/lib/functions/files.inc.php - Line 57',1355471449,'PHP',NULL,NULL),(2811,514,2,'GUI','E_WARNING\nfopen(/var/www/html/testlink/upload_area//executions/44/4822ee2bfc01e78afdcd85c18ef7975a.png): failed to open stream: No such file or directory - in /var/www/html/testlink/lib/functions/files.inc.php - Line 57',1355471411,'PHP',NULL,NULL),(2810,513,2,'GUI','E_WARNING\nfopen(/var/www/html/testlink/upload_area//executions/44/0c294d1f48f886e59d1cd678734ebff2.png): failed to open stream: No such file or directory - in /var/www/html/testlink/lib/functions/files.inc.php - Line 57',1355471405,'PHP',NULL,NULL),(2809,512,2,'GUI','E_WARNING\nfopen(/var/www/html/testlink/upload_area//executions/44/4feb217d8a4aaa571acf7c72992765c8.png): failed to open stream: No such file or directory - in /var/www/html/testlink/lib/functions/files.inc.php - Line 57',1355471393,'PHP',NULL,NULL),(2808,511,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:21:\"audit_login_succeeded\";s:6:\"params\";a:2:{i:0;s:5:\"jonas\";i:1;s:11:\"62.80.223.2\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355471182,'LOGIN',2,'users'),(2807,510,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:40:\"After excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 11:46:46.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355465849,'CREATE',49,'attachments'),(2805,508,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355465725,'PHP',NULL,NULL),(2806,509,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:41:\"Before excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 11:42:59.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355465833,'CREATE',49,'attachments'),(2804,507,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355465702,'PHP',NULL,NULL),(2803,507,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:88:\"CIKABNFS-16 : Increase product quantity by 30; closing previous decrease request tickets\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355465702,'ASSIGN',539,'testplans'),(2802,506,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:40:\"After excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 11:32:22.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355465006,'CREATE',48,'attachments'),(2801,505,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:41:\"Before excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 11:30:11.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355464991,'CREATE',48,'attachments'),(2800,504,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355464965,'PHP',NULL,NULL),(2799,503,2,'GUI','E_NOTICE\nUndefined property: stdClass::$steps_results_layout - in /var/www/html/testlink/gui/templates_c/%%2E^2E1^2E11686C%%tcView_viewer.tpl.php - Line 268',1355464943,'PHP',NULL,NULL),(2798,503,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:26:\"audit_tc_added_to_testplan\";s:6:\"params\";a:3:{i:0;s:88:\"CIKABNFS-17 : Decrease product quantity by 30; closing previous increase request tickets\";i:1;s:1:\"1\";i:2;s:69:\"Testing vTiger and biker-portal version 5.4.0 with new funtionalities\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355464943,'ASSIGN',539,'testplans'),(2797,502,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:40:\"After excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 11:02:03.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355463173,'CREATE',47,'attachments'),(2795,500,2,'GUI','E_WARNING\nMissing argument 4 for write_execution(), called in /var/www/html/testlink/lib/execute/execSetResults.php on line 238 and defined - in /var/www/html/testlink/lib/functions/exec.inc.php - Line 78',1355463128,'PHP',NULL,NULL),(2796,501,16,'GUI','O:18:\"tlMetaStringHelper\":4:{s:5:\"label\";s:24:\"audit_attachment_created\";s:6:\"params\";a:2:{i:0;s:41:\"Before excution list of tickets in vTiger\";i:1;s:39:\"Screenshot from 2012-12-14 10:42:17.png\";}s:13:\"bDontLocalize\";b:0;s:14:\"bDontFireEvent\";b:0;}',1355463154,'CREATE',47,'attachments');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `execution_bugs`
--

DROP TABLE IF EXISTS `execution_bugs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `execution_bugs` (
  `execution_id` int(10) unsigned NOT NULL DEFAULT '0',
  `bug_id` varchar(16) NOT NULL DEFAULT '0',
  PRIMARY KEY (`execution_id`,`bug_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `execution_bugs`
--

LOCK TABLES `execution_bugs` WRITE;
/*!40000 ALTER TABLE `execution_bugs` DISABLE KEYS */;
/*!40000 ALTER TABLE `execution_bugs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `executions`
--

DROP TABLE IF EXISTS `executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `executions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `build_id` int(10) NOT NULL DEFAULT '0',
  `tester_id` int(10) unsigned DEFAULT NULL,
  `execution_ts` datetime DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT '0',
  `tcversion_number` smallint(5) unsigned NOT NULL DEFAULT '1',
  `platform_id` int(10) unsigned NOT NULL DEFAULT '0',
  `execution_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 -> manual, 2 -> automated',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `executions_idx1` (`testplan_id`,`tcversion_id`,`platform_id`,`build_id`),
  KEY `executions_idx2` (`execution_type`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `executions`
--

LOCK TABLES `executions` WRITE;
/*!40000 ALTER TABLE `executions` DISABLE KEYS */;
INSERT INTO `executions` VALUES (1,2,2,'2012-03-19 16:59:58','p',10,13,1,0,1,'It worked fine. Created Salers Orders: ORD10, ORD11, ORD12, QUO10, QUO11, QUO12'),(2,6,4,'2012-03-23 07:48:59','p',40,47,1,0,1,''),(3,6,4,'2012-05-23 11:46:40','p',40,95,1,0,1,'All test cases are verified and executed successfully'),(4,7,4,'2012-05-28 09:38:30','p',100,95,1,0,1,'All the test cases successfully executed'),(5,7,4,'2012-06-11 14:28:46','p',100,97,1,0,1,'All test cases are verified and we have passed the result.'),(6,7,4,'2012-06-11 14:41:35','p',100,99,1,0,1,'All the testcases are verified and the result is passed.'),(7,8,6,'2012-10-01 10:32:36','p',498,392,1,1,1,''),(8,8,6,'2012-10-01 10:33:18','p',498,389,1,1,1,''),(9,8,6,'2012-10-01 10:33:34','p',498,416,1,1,1,''),(10,8,6,'2012-10-01 10:33:50','p',498,419,1,1,1,''),(11,8,6,'2012-10-01 10:41:55','p',498,422,1,1,1,''),(12,8,6,'2012-10-01 10:42:22','p',498,361,1,1,1,''),(13,8,6,'2012-10-01 10:42:32','p',498,364,1,1,1,''),(14,8,6,'2012-10-01 10:42:47','p',498,369,1,1,1,''),(15,8,6,'2012-10-01 10:44:40','p',498,398,1,1,1,''),(16,8,6,'2012-10-01 10:45:16','p',498,403,1,1,1,''),(17,8,6,'2012-10-01 10:47:30','p',498,406,1,1,1,''),(18,8,6,'2012-10-01 10:48:14','p',498,424,1,1,1,''),(19,8,6,'2012-10-01 10:48:35','p',498,430,1,1,1,''),(20,8,6,'2012-10-01 10:50:00','p',498,427,1,1,1,''),(21,8,6,'2012-10-01 10:56:39','p',498,500,1,1,1,''),(22,8,6,'2012-10-01 10:57:21','p',498,434,1,1,1,''),(23,8,6,'2012-10-01 11:10:28','p',498,490,1,1,1,''),(24,8,6,'2012-10-01 11:35:28','f',498,480,1,1,1,''),(25,8,6,'2012-10-01 11:36:05','p',498,440,1,1,1,''),(26,9,6,'2012-10-08 12:25:07','p',502,361,1,2,1,''),(27,9,6,'2012-10-08 12:25:19','p',502,364,1,2,1,''),(28,9,6,'2012-10-08 12:25:27','p',502,369,1,2,1,''),(29,9,6,'2012-10-08 12:25:40','p',502,384,1,2,1,''),(30,9,6,'2012-10-08 12:26:03','p',502,392,1,2,1,''),(31,9,6,'2012-10-08 12:26:48','p',502,389,1,2,1,''),(32,9,6,'2012-10-08 12:27:06','p',502,416,1,2,1,''),(33,9,6,'2012-10-08 12:27:21','p',502,419,1,2,1,''),(34,9,6,'2012-10-08 12:27:49','p',502,422,1,2,1,''),(35,9,6,'2012-10-08 12:28:03','p',502,422,1,2,1,''),(36,9,6,'2012-10-08 12:28:40','p',502,398,1,2,1,''),(37,9,6,'2012-10-08 12:28:49','p',502,403,1,2,1,''),(38,9,6,'2012-10-08 12:29:30','p',502,410,1,2,1,''),(39,9,6,'2012-10-08 12:29:37','p',502,424,1,2,1,''),(40,9,6,'2012-10-08 12:29:50','p',502,430,1,2,1,''),(41,10,7,'2012-12-13 10:28:20','p',539,541,1,0,1,''),(42,10,7,'2012-12-13 10:28:35','p',539,544,1,0,1,''),(43,10,7,'2012-12-13 11:44:02','p',539,557,1,0,1,'<p><b>Before at biker portal</b></p>\r\n<table cellspacing=\"0\" cellpadding=\"5\" border=\"1\" align=\"center\"><tbody><tr align=\"center\">\r\n	      <td class=\"detailedViewHeader\">Product Id</td>\r\n	      <td class=\"detailedViewHeader\">Product Name</td>\r\n	      <td class=\"detailedViewHeader\">Description</td>\r\n	      <td class=\"detailedViewHeader\">Order</td>\r\n	      <td class=\"detailedViewHeader\">Sale Order</td>\r\n	      <td class=\"detailedViewHeader\">Left Order</td>\r\n	       <td class=\"detailedViewHeader\">Action</td>\r\n	        </tr><tr class=\"dvtLabel\"> <td>PRO1</td><td>202035</td>\r\n	        <td>SPARKCYKEL ROSA</td>\r\n	        <td>100</td> \r\n	       <td>10</td>\r\n	       <td>90</td>\r\n	          <td>\r\n	          <select onchange=\"calllightbox(this.value,90,\'PRO1\',\'BUT125\',this.id)\" id=\"202035\" name=\"saleaction\">\r\n	          <option value=\"\">Select</option>\r\n	          <option value=\"Call off\">Call off</option>\r\n	          <option value=\"Release\">Release</option>\r\n	          <option value=\"Increase\">Increase</option>\r\n	          </select></td>\r\n	     </tr> \r\n	   \r\n	 </tbody></table>\r\n<p><b>After call-offs the quantity by 10 at biker portal</b></p>\r\n<table \"cellspacing=\"0\" cellpadding=\"5\" border=\"1\" align=\"center\"><tbody><tr align=\"center\">\r\n	      <td class=\"detailedViewHeader\">Product Id</td>\r\n	      <td class=\"detailedViewHeader\">Product Name</td>\r\n	      <td class=\"detailedViewHeader\">Description</td>\r\n	      <td class=\"detailedViewHeader\">Order</td>\r\n	      <td class=\"detailedViewHeader\">Sale Order</td>\r\n	      <td class=\"detailedViewHeader\">Left Order</td>\r\n	       <td class=\"detailedViewHeader\">Action</td>\r\n	        </tr><tr class=\"dvtLabel\"> <td>PRO1</td><td>202035</td>\r\n	        <td>SPARKCYKEL ROSA</td>\r\n	        <td>100</td> \r\n	       <td>20</td>\r\n	       <td>80</td>\r\n	          <td>\r\n	          <select onchange=\"calllightbox(this.value,80,\'PRO1\',\'\',this.id)\" id=\"202035\" name=\"saleaction\">\r\n	          <option value=\"\">Select</option>\r\n	          <option value=\"Call off\">Call off</option>\r\n	          <option value=\"Release\">Release</option>\r\n	          <option value=\"Increase\">Increase</option>\r\n	          </select></td>\r\n	     </tr> \r\n	   \r\n	 </tbody></table>'),(44,10,7,'2012-12-13 12:16:28','p',539,564,1,0,1,''),(45,10,7,'2012-12-13 12:33:18','p',539,570,1,0,1,'We were having one ticket open for increase product with the quantity 10 and executing this, it closed the previous ticket and closed the newly created ticket; since the quantity were same.'),(46,10,7,'2012-12-14 06:18:27','p',539,576,1,0,1,''),(47,10,7,'2012-12-14 06:32:08','p',539,582,1,0,1,''),(48,10,7,'2012-12-14 07:02:45','p',539,594,1,0,1,''),(49,10,7,'2012-12-14 07:15:25','p',539,588,1,0,1,''),(50,10,7,'2012-12-20 12:50:41','p',539,600,1,0,1,'');
/*!40000 ALTER TABLE `executions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testproject_id` int(10) unsigned NOT NULL,
  `owner_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `ipaddress` varchar(255) NOT NULL,
  `content` text,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modification_ts` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `inventory_idx1` (`testproject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keywords`
--

DROP TABLE IF EXISTS `keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(100) NOT NULL DEFAULT '',
  `testproject_id` int(10) unsigned NOT NULL DEFAULT '0',
  `notes` text,
  PRIMARY KEY (`id`),
  KEY `testproject_id` (`testproject_id`),
  KEY `keyword` (`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keywords`
--

LOCK TABLES `keywords` WRITE;
/*!40000 ALTER TABLE `keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `milestones`
--

DROP TABLE IF EXISTS `milestones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `milestones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `target_date` date DEFAULT NULL,
  `start_date` date NOT NULL DEFAULT '0000-00-00',
  `a` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `b` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `c` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT 'undefined',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_testplan_id` (`name`,`testplan_id`),
  KEY `testplan_id` (`testplan_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `milestones`
--

LOCK TABLES `milestones` WRITE;
/*!40000 ALTER TABLE `milestones` DISABLE KEYS */;
INSERT INTO `milestones` VALUES (1,7,'2012-05-31','0000-00-00',0,0,0,'A first milestone'),(2,10,'2012-03-09','0000-00-00',0,0,0,'Finish test');
/*!40000 ALTER TABLE `milestones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `node_types`
--

DROP TABLE IF EXISTS `node_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `node_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT 'testproject',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `node_types`
--

LOCK TABLES `node_types` WRITE;
/*!40000 ALTER TABLE `node_types` DISABLE KEYS */;
INSERT INTO `node_types` VALUES (1,'testproject'),(2,'testsuite'),(3,'testcase'),(4,'testcase_version'),(5,'testplan'),(6,'requirement_spec'),(7,'requirement'),(8,'requirement_version'),(9,'testcase_step'),(10,'requirement_revision');
/*!40000 ALTER TABLE `node_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nodes_hierarchy`
--

DROP TABLE IF EXISTS `nodes_hierarchy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nodes_hierarchy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `node_type_id` int(10) unsigned NOT NULL DEFAULT '1',
  `node_order` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid_m_nodeorder` (`parent_id`,`node_order`)
) ENGINE=MyISAM AUTO_INCREMENT=627 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nodes_hierarchy`
--

LOCK TABLES `nodes_hierarchy` WRITE;
/*!40000 ALTER TABLE `nodes_hierarchy` DISABLE KEYS */;
INSERT INTO `nodes_hierarchy` VALUES (1,'First test project',NULL,1,1),(2,'Test Suit 1',1,2,1),(3,'First test case',2,3,100),(4,'',3,4,0),(5,'Second test case',2,3,101),(6,'',5,4,0),(7,'First test plan',1,5,0),(8,'Cikab Nonfood season',NULL,1,1),(10,'Cikab screen for creation of trouble tickets',8,5,0),(11,'Cikab Trouble Ticket screen',8,2,1),(12,'Verify the logic for sales orders and quotes in the portal',11,3,100),(13,'',12,4,0),(28,'',13,9,0),(27,'',13,9,0),(25,'',13,9,0),(26,'',13,9,0),(24,'',13,9,0),(19,'',13,9,0),(22,'Sales Order Screen in the Portal',8,2,2),(23,'Vendor Portal',8,2,3),(29,'',13,9,0),(30,'',13,9,0),(31,'',13,9,0),(32,'',13,9,0),(33,'',13,9,0),(34,'',13,9,0),(35,'',13,9,0),(36,'',13,9,0),(37,'',13,9,0),(38,'',13,9,0),(39,'',13,9,0),(40,'Test of Sales ORder Screen',8,5,0),(46,'Check Sales Orders as Store and Central user',22,3,100),(48,'',46,4,0),(47,'',46,4,0),(45,'Test plan for ashish',8,5,0),(53,'',48,9,0),(50,'',48,9,0),(55,'',48,9,0),(54,'',48,9,0),(56,'',48,9,0),(57,'',48,9,0),(58,'',48,9,0),(59,'',48,9,0),(60,'',48,9,0),(61,'',48,9,0),(62,'',48,9,0),(63,'',48,9,0),(64,'',48,9,0),(65,'',48,9,0),(66,'',48,9,0),(67,'',48,9,0),(68,'',48,9,0),(69,'',48,9,0),(70,'',48,9,0),(71,'',48,9,0),(72,'',48,9,0),(73,'',48,9,0),(74,'',48,9,0),(75,'',48,9,0),(76,'',48,9,0),(77,'',48,9,0),(78,'',48,9,0),(79,'',48,9,0),(80,'',48,9,0),(81,'',48,9,0),(82,'',48,9,0),(83,'',48,9,0),(84,'',48,9,0),(85,'',48,9,0),(86,'',48,9,0),(87,'',48,9,0),(88,'',48,9,0),(89,'',48,9,0),(90,'',48,9,0),(91,'',48,9,0),(92,'',48,9,0),(93,'Sales Order Export Interface',8,2,4),(94,'PHP Job 1 - extract',93,3,100),(95,'',94,4,0),(96,'PHP Job 2 – format and enque',93,3,101),(97,'',96,4,0),(98,'PHP Job 3 – dequeue and send over ftp',93,3,102),(99,'',98,4,0),(100,'Test of Sales Order Export',8,5,0),(101,'',95,9,0),(102,'',95,9,0),(103,'',95,9,0),(104,'',95,9,0),(105,'',95,9,0),(106,'',95,9,0),(107,'',95,9,0),(108,'',95,9,0),(109,'',95,9,0),(110,'',95,9,0),(111,'',95,9,0),(112,'',95,9,0),(113,'',95,9,0),(114,'',95,9,0),(115,'',95,9,0),(116,'',95,9,0),(117,'',95,9,0),(118,'',97,9,0),(119,'',97,9,0),(120,'',97,9,0),(121,'',97,9,0),(122,'',97,9,0),(123,'',97,9,0),(124,'',97,9,0),(125,'',97,9,0),(126,'',97,9,0),(127,'',97,9,0),(128,'',97,9,0),(129,'',97,9,0),(130,'',97,9,0),(158,'',145,9,0),(157,'',145,9,0),(156,'',145,9,0),(155,'',145,9,0),(154,'',145,9,0),(153,'',145,9,0),(152,'',145,9,0),(151,'',145,9,0),(150,'',145,9,0),(149,'',145,9,0),(148,'',145,9,0),(147,'',145,9,0),(146,'',145,9,0),(145,'',94,4,0),(159,'',145,9,0),(160,'',145,9,0),(161,'',145,9,0),(162,'',145,9,0),(163,'',145,9,0),(165,'',97,9,0),(166,'',99,9,0),(167,'',99,9,0),(168,'',99,9,0),(169,'',99,9,0),(170,'',99,9,0),(171,'',99,9,0),(172,'',99,9,0),(173,'',99,9,0),(174,'',99,9,0),(175,'',99,9,0),(176,'',99,9,0),(177,'',99,9,0),(178,'',99,9,0),(179,'',99,9,0),(180,'',99,9,0),(181,'',99,9,0),(182,'',99,9,0),(183,'',99,9,0),(185,'Clab Trailer App and portal',8,5,0),(186,'Clab Trailer App and Portal',NULL,1,1),(187,'Cikab Survey Report',186,2,0),(188,'Driver reports a damage on a trailer not having any damages',186,2,1),(194,'',192,9,0),(193,'',192,9,0),(191,'Cikab survey ',187,3,101),(192,'',191,4,0),(195,'',192,9,0),(196,'',192,9,0),(197,'',192,9,0),(198,'',192,9,0),(199,'',192,9,0),(200,'',192,9,0),(201,'',192,9,0),(202,'',192,9,0),(203,'',192,9,0),(204,'',192,9,0),(205,'',192,9,0),(206,'',192,9,0),(207,'',192,9,0),(208,'',192,9,0),(209,'',192,9,0),(210,'',192,9,0),(211,'',192,9,0),(212,'',192,9,0),(213,'',192,9,0),(214,'',192,9,0),(215,'',192,9,0),(216,'',192,9,0),(217,'',192,9,0),(218,'',192,9,0),(219,'',192,9,0),(220,'',192,9,0),(221,'trailer not having any damages',188,3,0),(222,'',221,4,0),(358,'Trailer mobile application',355,2,1),(224,'Driver reports a damage on a trailer that has one damage',186,2,2),(225,'Driver reports a on a trailer that has ten damages',186,2,3),(355,'GsLabs Trailer App',NULL,1,1),(227,'Trailer is taken into operation after the repair, the trouble tickets for t',186,2,5),(359,'Login test',358,2,0),(231,'Driver reports a survey without any damage',186,2,4),(232,'Driver reports a survey without any damage',231,3,100),(233,'',232,4,0),(234,'',233,9,0),(235,'',233,9,0),(236,'',233,9,0),(237,'',233,9,0),(238,'',233,9,0),(239,'',233,9,0),(240,'',233,9,0),(241,'',233,9,0),(242,'',233,9,0),(243,'',233,9,0),(244,'',233,9,0),(245,'',233,9,0),(246,'',233,9,0),(247,'',233,9,0),(248,'',233,9,0),(249,'',233,9,0),(250,'',233,9,0),(251,'',233,9,0),(252,'',222,9,0),(253,'',222,9,0),(254,'',222,9,0),(255,'',222,9,0),(256,'',222,9,0),(257,'',222,9,0),(258,'',222,9,0),(259,'',222,9,0),(260,'',222,9,0),(261,'',222,9,0),(262,'',222,9,0),(263,'',222,9,0),(264,'',222,9,0),(265,'',222,9,0),(266,'',222,9,0),(267,'',222,9,0),(268,'',222,9,0),(269,'',222,9,0),(270,'Driver reports a damage on a trailer that has one damage',224,3,100),(271,'',270,4,0),(272,'',271,9,0),(273,'',271,9,0),(274,'',271,9,0),(275,'',271,9,0),(276,'',271,9,0),(277,'',271,9,0),(278,'',271,9,0),(279,'',271,9,0),(280,'',271,9,0),(281,'',271,9,0),(282,'',271,9,0),(283,'',271,9,0),(284,'',271,9,0),(285,'',271,9,0),(286,'',271,9,0),(287,'',271,9,0),(288,'',271,9,0),(289,'',271,9,0),(291,'Driver reports a on a trailer that has ten damages',225,3,100),(292,'',291,4,0),(293,'',292,9,0),(294,'',292,9,0),(295,'',292,9,0),(296,'',292,9,0),(297,'',292,9,0),(298,'',292,9,0),(299,'',292,9,0),(300,'',292,9,0),(301,'',292,9,0),(302,'',292,9,0),(303,'',292,9,0),(304,'',292,9,0),(305,'',292,9,0),(306,'',292,9,0),(307,'',292,9,0),(308,'',292,9,0),(309,'',292,9,0),(310,'',292,9,0),(311,'Trailer repaired and trouble tickets closed',227,3,100),(312,'',311,4,0),(313,'',312,9,0),(314,'',312,9,0),(315,'',312,9,0),(316,'',312,9,0),(317,'',312,9,0),(318,'',312,9,0),(319,'',312,9,0),(320,'',312,9,0),(321,'',312,9,0),(322,'',312,9,0),(323,'',312,9,0),(324,'',312,9,0),(325,'',312,9,0),(326,'',312,9,0),(327,'',312,9,0),(328,'',312,9,0),(329,'',312,9,0),(330,'',312,9,0),(331,'',312,9,0),(332,'',312,9,0),(333,'',312,9,0),(334,'',312,9,0),(335,'',312,9,0),(336,'',312,9,0),(337,'',312,9,0),(338,'',312,9,0),(339,'',312,9,0),(340,'',312,9,0),(341,'',312,9,0),(342,'',312,9,0),(343,'',312,9,0),(344,'',312,9,0),(345,'',312,9,0),(346,'',312,9,0),(347,'',312,9,0),(348,'',312,9,0),(349,'',312,9,0),(350,'',312,9,0),(351,'',312,9,0),(352,'',312,9,0),(353,'',312,9,0),(354,'',312,9,0),(360,'login to app',359,3,0),(361,'',360,4,0),(362,'',361,9,0),(363,'Blank user_name field',359,3,1),(364,'',363,4,0),(365,'',364,9,0),(366,'',364,9,0),(367,'',364,9,0),(368,' Blank password field',359,3,2),(369,'',368,4,0),(370,'',369,9,0),(371,'',369,9,0),(372,'',369,9,0),(373,'Incorrect username',359,3,3),(374,'',373,4,0),(375,'',374,9,0),(376,'',374,9,0),(377,'',374,9,0),(378,'Incorrect password',359,3,4),(379,'',378,4,0),(380,'',379,9,0),(381,'',379,9,0),(382,'',379,9,0),(383,'Correct username and correct password',359,3,5),(384,'',383,4,0),(385,'',384,9,0),(386,'',384,9,0),(387,'',384,9,0),(388,'Logout Functinality',413,3,7),(389,'',388,4,0),(390,'',389,9,0),(391,'Reset functinality',413,3,1),(392,'',391,4,0),(393,'',392,9,0),(394,'State chage of button Damages',413,3,2),(395,'',394,4,0),(396,'',395,9,0),(397,'In Damage details tapping on Type',414,3,0),(398,'',397,4,0),(399,'',398,9,0),(400,'',398,9,0),(401,'',398,9,0),(402,'In damage details tapping on position without selecting type',414,3,4),(403,'',402,4,0),(404,'',403,9,0),(405,'Reporting duplcate Damage',414,3,5),(406,'',405,4,0),(407,'',406,9,0),(408,'',406,9,0),(409,'In Damage Details check for Type and position pair',414,3,6),(410,'',409,4,0),(411,'',410,9,0),(412,'',410,9,0),(413,'Home screen test',358,2,8),(414,'Damage Details test',358,2,9),(415,'Tap on ID',413,3,8),(416,'',415,4,0),(417,'',416,9,0),(418,'Tap on Place',413,3,9),(419,'',418,4,0),(420,'',419,9,0),(421,'Submit button functionality',413,3,10),(422,'',421,4,0),(423,'Add a new image button Functionality',414,3,7),(424,'',423,4,0),(425,'',424,9,0),(426,'Tap on Previously reported damage',358,3,10),(427,'',426,4,0),(428,'',427,9,0),(429,'Submit button functionality',414,3,8),(430,'',429,4,0),(431,'',430,9,0),(432,'Integration test cases',358,2,11),(433,'Driver reports a damage on a trailer that has one damage',432,3,3),(434,'',433,4,0),(472,'',457,9,0),(473,'',434,9,0),(471,'',457,9,0),(490,'',489,4,0),(491,'',490,9,0),(439,'Driver reports a survey without any damage',432,3,4),(486,'',440,9,0),(440,'',439,4,0),(488,'',440,9,0),(489,'Trailer is in operation after the repair, the trouble tickets for the repaired damages are closed',432,3,0),(487,'',440,9,0),(443,'',434,9,0),(444,'',434,9,0),(445,'',434,9,0),(446,'',434,9,0),(447,'',434,9,0),(448,'',434,9,0),(449,'',434,9,0),(450,'',434,9,0),(451,'',434,9,0),(452,'',434,9,0),(453,'',434,9,0),(454,'',434,9,0),(455,'',434,9,0),(456,'Driver reports a on a trailer that has ten damages',432,3,2),(457,'',456,4,0),(458,'',457,9,0),(459,'',457,9,0),(460,'',457,9,0),(461,'',457,9,0),(462,'',457,9,0),(463,'',457,9,0),(464,'',457,9,0),(465,'',457,9,0),(466,'',457,9,0),(467,'',457,9,0),(468,'',457,9,0),(469,'',457,9,0),(470,'',457,9,0),(474,'',440,9,0),(475,'',440,9,0),(476,'',440,9,0),(477,'',440,9,0),(478,'',440,9,0),(479,'Trailer is taken out of operation and into repair',432,3,1),(480,'',479,4,0),(481,'',480,9,0),(482,'',480,9,0),(483,'',480,9,0),(492,'',490,9,0),(493,'',490,9,0),(494,'',490,9,0),(495,'',490,9,0),(498,'Damage claim',355,5,0),(497,'',422,9,0),(499,'tap on link or copy and paste it in browser\'s address bar',432,3,5),(500,'',499,4,0),(501,'',500,9,0),(502,'Damage claim Android',355,5,0),(539,'Testing vTiger and biker-portal version 5.4.0 with new funtionalities',8,5,0),(540,'Create Quotation',542,3,0),(541,'',540,4,0),(542,'Test vTiger and Biker Portal version 5.4.0',8,2,5),(543,'Create Sales Order',542,3,1),(544,'',543,4,0),(545,'',541,9,0),(546,'',541,9,0),(547,'',541,9,0),(548,'',541,9,0),(549,'',544,9,0),(550,'',544,9,0),(551,'',544,9,0),(552,'',544,9,0),(553,'',544,9,0),(554,'',544,9,0),(555,'',544,9,0),(556,'Create Sales Order Call-Offs at biker portal',542,3,2),(557,'',556,4,0),(558,'',557,9,0),(559,'',557,9,0),(560,'',557,9,0),(561,'',557,9,0),(562,'',557,9,0),(563,'Increase product quantity by 10.',542,3,3),(564,'',563,4,0),(565,'',564,9,0),(566,'',564,9,0),(567,'',564,9,0),(568,'',564,9,0),(569,'Decrease product quantity by 10.',542,3,4),(570,'',569,4,0),(571,'',570,9,0),(572,'',570,9,0),(573,'',570,9,0),(574,'',570,9,0),(575,'Decrease product quantity by 30',542,3,5),(576,'',575,4,0),(577,'',576,9,0),(578,'',576,9,0),(579,'',576,9,0),(580,'',576,9,0),(581,'Increase product quantity by 50',542,3,6),(582,'',581,4,0),(583,'',582,9,0),(584,'',582,9,0),(585,'',582,9,0),(586,'',582,9,0),(587,'Increase product quantity by 30; closing previous decrease request tickets',542,3,7),(588,'',587,4,0),(589,'',588,9,0),(590,'',588,9,0),(591,'',588,9,0),(592,'',588,9,0),(593,'Decrease product quantity by 30; closing previous increase request tickets',542,3,8),(594,'',593,4,0),(595,'',594,9,0),(596,'',594,9,0),(597,'',594,9,0),(598,'',594,9,0),(599,'Automate maching between realese and increase ticket.',542,3,9),(600,'',599,4,0),(601,'',600,9,0),(602,'',600,9,0),(603,'',600,9,0),(604,'',600,9,0),(605,'',600,9,0),(606,'',600,9,0),(607,'',600,9,0),(608,'',600,9,0),(609,'',600,9,0),(610,'',600,9,0),(611,'',600,9,0),(612,'',600,9,0),(613,'',600,9,0),(614,'',600,9,0),(615,'',600,9,0),(616,'',600,9,0),(617,'',600,9,0),(618,'',600,9,0),(619,'',600,9,0),(620,'',600,9,0),(621,'',600,9,0),(622,'',600,9,0),(623,'',600,9,0),(624,'',600,9,0),(625,'',600,9,0),(626,'',600,9,0);
/*!40000 ALTER TABLE `nodes_hierarchy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `object_keywords`
--

DROP TABLE IF EXISTS `object_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `object_keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fk_table` varchar(30) DEFAULT '',
  `keyword_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `object_keywords`
--

LOCK TABLES `object_keywords` WRITE;
/*!40000 ALTER TABLE `object_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `object_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platforms`
--

DROP TABLE IF EXISTS `platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platforms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `testproject_id` int(10) unsigned NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_platforms` (`testproject_id`,`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platforms`
--

LOCK TABLES `platforms` WRITE;
/*!40000 ALTER TABLE `platforms` DISABLE KEYS */;
INSERT INTO `platforms` VALUES (1,'Apple iphone 4s',355,'os: ios 5'),(2,'Google nexus',355,'');
/*!40000 ALTER TABLE `platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_coverage`
--

DROP TABLE IF EXISTS `req_coverage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_coverage` (
  `req_id` int(10) NOT NULL,
  `testcase_id` int(10) NOT NULL,
  KEY `req_testcase` (`req_id`,`testcase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='relation test case ** requirements';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_coverage`
--

LOCK TABLES `req_coverage` WRITE;
/*!40000 ALTER TABLE `req_coverage` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_coverage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_relations`
--

DROP TABLE IF EXISTS `req_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source_id` int(10) unsigned NOT NULL,
  `destination_id` int(10) unsigned NOT NULL,
  `relation_type` smallint(5) unsigned NOT NULL DEFAULT '1',
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_relations`
--

LOCK TABLES `req_relations` WRITE;
/*!40000 ALTER TABLE `req_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_revisions`
--

DROP TABLE IF EXISTS `req_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_revisions` (
  `parent_id` int(10) unsigned NOT NULL,
  `id` int(10) unsigned NOT NULL,
  `revision` smallint(5) unsigned NOT NULL DEFAULT '1',
  `req_doc_id` varchar(64) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `scope` text,
  `status` char(1) NOT NULL DEFAULT 'V',
  `type` char(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_open` tinyint(1) NOT NULL DEFAULT '1',
  `expected_coverage` int(10) NOT NULL DEFAULT '1',
  `log_message` text,
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifier_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_revisions_uidx1` (`parent_id`,`revision`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_revisions`
--

LOCK TABLES `req_revisions` WRITE;
/*!40000 ALTER TABLE `req_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_specs`
--

DROP TABLE IF EXISTS `req_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_specs` (
  `id` int(10) unsigned NOT NULL,
  `testproject_id` int(10) unsigned NOT NULL,
  `doc_id` varchar(64) NOT NULL,
  `scope` text,
  `total_req` int(10) NOT NULL DEFAULT '0',
  `type` char(1) DEFAULT 'n',
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifier_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `req_spec_uk1` (`doc_id`,`testproject_id`),
  KEY `testproject_id` (`testproject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Dev. Documents (e.g. System Requirements Specification)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_specs`
--

LOCK TABLES `req_specs` WRITE;
/*!40000 ALTER TABLE `req_specs` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `req_versions`
--

DROP TABLE IF EXISTS `req_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `req_versions` (
  `id` int(10) unsigned NOT NULL,
  `version` smallint(5) unsigned NOT NULL DEFAULT '1',
  `revision` smallint(5) unsigned NOT NULL DEFAULT '1',
  `scope` text,
  `status` char(1) NOT NULL DEFAULT 'V',
  `type` char(1) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_open` tinyint(1) NOT NULL DEFAULT '1',
  `expected_coverage` int(10) NOT NULL DEFAULT '1',
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifier_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_message` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `req_versions`
--

LOCK TABLES `req_versions` WRITE;
/*!40000 ALTER TABLE `req_versions` DISABLE KEYS */;
/*!40000 ALTER TABLE `req_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requirements`
--

DROP TABLE IF EXISTS `requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requirements` (
  `id` int(10) unsigned NOT NULL,
  `srs_id` int(10) unsigned NOT NULL,
  `req_doc_id` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `requirements_req_doc_id` (`srs_id`,`req_doc_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requirements`
--

LOCK TABLES `requirements` WRITE;
/*!40000 ALTER TABLE `requirements` DISABLE KEYS */;
/*!40000 ALTER TABLE `requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rights`
--

DROP TABLE IF EXISTS `rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rights` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rights_descr` (`description`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rights`
--

LOCK TABLES `rights` WRITE;
/*!40000 ALTER TABLE `rights` DISABLE KEYS */;
INSERT INTO `rights` VALUES (1,'testplan_execute'),(2,'testplan_create_build'),(3,'testplan_metrics'),(4,'testplan_planning'),(5,'testplan_user_role_assignment'),(6,'mgt_view_tc'),(7,'mgt_modify_tc'),(8,'mgt_view_key'),(9,'mgt_modify_key'),(10,'mgt_view_req'),(11,'mgt_modify_req'),(12,'mgt_modify_product'),(13,'mgt_users'),(14,'role_management'),(15,'user_role_assignment'),(16,'mgt_testplan_create'),(17,'cfield_view'),(18,'cfield_management'),(19,'system_configuration'),(20,'mgt_view_events'),(21,'mgt_view_usergroups'),(22,'events_mgt'),(23,'testproject_user_role_assignment'),(24,'platform_management'),(25,'platform_view'),(26,'project_inventory_management'),(27,'project_inventory_view');
/*!40000 ALTER TABLE `rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `risk_assignments`
--

DROP TABLE IF EXISTS `risk_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `risk_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `node_id` int(10) unsigned NOT NULL DEFAULT '0',
  `risk` char(1) NOT NULL DEFAULT '2',
  `importance` char(1) NOT NULL DEFAULT 'M',
  PRIMARY KEY (`id`),
  UNIQUE KEY `risk_assignments_tplan_node_id` (`testplan_id`,`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `risk_assignments`
--

LOCK TABLES `risk_assignments` WRITE;
/*!40000 ALTER TABLE `risk_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `risk_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_rights`
--

DROP TABLE IF EXISTS `role_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_rights` (
  `role_id` int(10) NOT NULL DEFAULT '0',
  `right_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`,`right_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_rights`
--

LOCK TABLES `role_rights` WRITE;
/*!40000 ALTER TABLE `role_rights` DISABLE KEYS */;
INSERT INTO `role_rights` VALUES (4,3),(4,6),(4,7),(4,8),(4,9),(4,10),(4,11),(5,3),(5,6),(5,8),(6,1),(6,2),(6,3),(6,6),(6,7),(6,8),(6,9),(6,11),(6,25),(6,27),(7,1),(7,3),(7,6),(7,8),(8,1),(8,2),(8,3),(8,4),(8,5),(8,6),(8,7),(8,8),(8,9),(8,10),(8,11),(8,12),(8,13),(8,14),(8,15),(8,16),(8,17),(8,18),(8,19),(8,20),(8,21),(8,22),(8,23),(8,24),(8,25),(8,26),(8,27),(9,1),(9,2),(9,3),(9,4),(9,5),(9,6),(9,7),(9,8),(9,9),(9,10),(9,11),(9,15),(9,16),(9,24),(9,25),(9,26),(9,27);
/*!40000 ALTER TABLE `role_rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(100) NOT NULL DEFAULT '',
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_rights_roles_descr` (`description`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'<reserved system role 1>',NULL),(2,'<reserved system role 2>',NULL),(3,'<no rights>',NULL),(4,'test designer',NULL),(5,'guest',NULL),(6,'senior tester',NULL),(7,'tester',NULL),(8,'admin',NULL),(9,'leader',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcsteps`
--

DROP TABLE IF EXISTS `tcsteps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tcsteps` (
  `id` int(10) unsigned NOT NULL,
  `step_number` int(11) NOT NULL DEFAULT '1',
  `actions` text,
  `expected_results` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `execution_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 -> manual, 2 -> automated',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tcsteps`
--

LOCK TABLES `tcsteps` WRITE;
/*!40000 ALTER TABLE `tcsteps` DISABLE KEYS */;
INSERT INTO `tcsteps` VALUES (28,7,'<p>Click on the button Duplicate Sales Order</p>\r\n<p>Change Status to Approved</p>\r\n<p>Click on Save</p>','<p>&nbsp;A new Sales Order is created</p>\r\n<p>Record the New Sales Order Number in the test results</p>',1,1),(29,8,'<p>&nbsp;Click in the button Duplicate Sales Order</p>\r\n<p>Cahnge Status to Delivered</p>\r\n<p>Click on Save</p>','<p>&nbsp;A new Sales Order is created</p>\r\n<p>Record the New Sales Order number in the test resutls</p>',1,1),(30,9,'<p>&nbsp;Click in the button Duplicate Sales Order</p>\r\n<p>Change Status to Cancelled</p>\r\n<p>Click on Save</p>','<p>&nbsp;A New Sales Order is created</p>\r\n<p>Record the New Sales Order Number in the test results</p>',1,1),(31,10,'<p>&nbsp;Click on Sales-&gt;Quotes</p>','<p>&nbsp;Quotes screen with list of Quotes</p>',1,1),(32,11,'<p>&nbsp;Click on + sign to create a new Quote</p>','<p>&nbsp;Create new Quote screen</p>',1,1),(33,12,'<p>&nbsp;Enter Subject CIKABNFS-1 in the Subject</p>\r\n<p>Click on + at Account Name and select Account test</p>\r\n<p>Scroll down to item details and click on Select Product icon</p>\r\n<p>Select product&nbsp;<a id=\"popup_product_7\" vt_prod_arr=\"{&quot;entityid&quot;:&quot;7&quot;,&quot;prodname&quot;:&quot;Cykel Velobris 21\\&quot;&quot;,&quot;unitprice&quot;:&quot;599.00&quot;,&quot;qtyinstk&quot;:&quot;0.000&quot;,&quot;taxstring&quot;:&quot;tax1=4.500,tax2=10.000,tax3=12.500&quot;,&quot;rowid&quot;:&quot;1&quot;,&quot;desc&quot;:&quot;&quot;,&quot;subprod_ids&quot;:&quot;::&quot;}\" style=\"color: rgb(0, 112, 186); font-family: Arial, Helvetica, sans-serif; font-size: 11px; background-color: rgb(255, 255, 204); \" href=\"\">Cykel Velobris 21&quot;</a></p>\r\n<p>Enter Quantity 10</p>\r\n<p>Set Billing and Shipping adress to -</p>\r\n<p>Click on Save</p>','<p>&nbsp;A new Quotes is created</p>\r\n<p>Record the Quote number in the test results</p>',1,1),(19,2,'','',1,1),(24,3,'<p>&nbsp;Login to vTiger</p>','<p>&nbsp;Start screen</p>',1,1),(25,4,'<p>&nbsp;Select Sales-&gt;Sales Order</p>','<p>&nbsp;Sales Order screen with list of Sales Orders</p>',1,1),(26,5,'<p>&nbsp;Click in + for adding new Sales Order</p>','<p>Crating New Sales Order screen</p>',1,1),(27,6,'<p>&nbsp;Enter Subject \'<span style=\"color: rgb(21, 66, 139); font-family: tahoma, arial, verdana, sans-serif; font-size: 11px; font-weight: bold; line-height: 15px; text-align: left; background-color: rgb(205, 222, 243); \">CIKABNFS-1&nbsp;</span>\' as Subject</p>\r\n<p>Click on + at Account Name and choose Account test</p>\r\n<p>Select Status Created</p>\r\n<p>Scroll down to Item Details and click on Select product icon</p>\r\n<p>Select product&nbsp;<a href=\"\" id=\"popup_product_7\" vt_prod_arr=\"{&quot;entityid&quot;:&quot;7&quot;,&quot;prodname&quot;:&quot;Cykel Velobris 21\\&quot;&quot;,&quot;unitprice&quot;:&quot;599.00&quot;,&quot;qtyinstk&quot;:&quot;0.000&quot;,&quot;taxstring&quot;:&quot;tax1=4.500,tax2=10.000,tax3=12.500&quot;,&quot;rowid&quot;:&quot;1&quot;,&quot;desc&quot;:&quot;&quot;,&quot;subprod_ids&quot;:&quot;::&quot;}\" style=\"color: rgb(0, 112, 186); font-family: Arial, Helvetica, sans-serif; font-size: 11px; background-color: rgb(255, 255, 204); \">Cykel Velobris 21&quot;</a></p>\r\n<p>Set quantity to two</p>\r\n<p>Set Billing andress to -</p>\r\n<p>Click on Save</p>\r\n<p>&nbsp;</p>','<p>A new Sales Order is created</p>\r\n<p>Record the New Sales Order Number in the test resutls\r\n<div>&nbsp;</div>\r\n</p>',1,1),(34,13,'<p>&nbsp;Click on the Duplicate Quote button</p>\r\n<p>Set stage to Delivered</p>\r\n<p>Click on Save&nbsp;</p>','<p>&nbsp;A new Quote is created</p>\r\n<p>Record the Quote number in the test results</p>',1,1),(35,14,'<p>&nbsp;Click on Duplicate Quote button</p>\r\n<p>Set stage to Reviewed</p>\r\n<p>Click on Save</p>','<p>&nbsp;A new Quote is created</p>\r\n<p>Record the quote number in the test results</p>',1,1),(36,15,'<p>&nbsp;Click in Duplicate Quote button</p>\r\n<p>Set stage to Accepted</p>\r\n<p>Click on Save</p>','<p>&nbsp;A new Quote is created</p>\r\n<p>Record the quote number in the test resutls</p>',1,1),(37,16,'<p>&nbsp;Clickon Duplicate Quote button</p>\r\n<p>Set stage to Rejected</p>\r\n<p>Click in Save</p>','<p>&nbsp;A new Quote is created</p>\r\n<p>Record the quote number in the test results</p>',1,1),(38,17,'<p>&nbsp;Click in the Sign Out link (upper right corner)</p>','<p>&nbsp;Login screen</p>',1,1),(39,18,'<p>Login to the customer portal&nbsp;</p>','<p>&nbsp;The \'Avrop fr&aring;n f&ouml;rhandsorder\' screen is showed</p>',1,1),(53,3,'<p>&nbsp;Select Sales-&gt;Sales Order</p>','<p>&nbsp;Sales Order screen with list of Sales Orders</p>',1,1),(50,2,'<p>Login to vTiger Portal(contact 1)</p>','<p>&nbsp;Start screen</p>',1,1),(54,4,'<p>For product 1(Cykel Velobris 21)</p>\r\n<p>select Visa : Alla</p>','<p>The Sales Orders for test are showed</p>',1,1),(55,5,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>a pop up window will appear,if we enter 33 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(56,6,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>if we enter 31 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(57,7,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>a  pop up window will appear,if we enter 33 in it,it will show a msg  &quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantitet&quot;</p>',1,1),(58,8,'<p>&nbsp;select Atgard : Frislapp</p>\r\n<p>&nbsp;</p>','<p>if we enter 30 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(59,9,'<p>select Atgard : Okaforhandsorder</p>','<p>if we enter 40 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>',1,1),(60,10,'<p>select Atgard : Okaforhandsorder</p>','<p>if we enter 30 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(61,11,'<p>For product 2(Brother Ink Jet Cartridge)</p>\r\n<p>select&nbsp; Visa : Alla</p>','<p>The Sales Orders for test are showed</p>',1,1),(62,12,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>a pop up window will appear,if we enter 6 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(63,13,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(64,14,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>a pop up window will appear,if we enter 6 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(65,15,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(66,16,'<p>select Atgard : Okaforhandsorder</p>','<p>if we enter 6 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(67,17,'<p>select Atgard : Okaforhandsorder</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(68,18,'<p>Login to vTiger Portal(contact 2)</p>','<p>Start screen</p>',1,1),(69,19,'<p>&nbsp;Select Sales-&gt;Sales Order</p>','<p>&nbsp;Sales Order screen with list of Sales Orders</p>',1,1),(70,20,'<p>For product 1(Cykel Velobris 21)</p>\r\n<p>select Visa : Alla</p>\r\n<p>&nbsp;</p>','<p>The Sales Orders for test are showed</p>',1,1),(71,21,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>a pop up window will appear,if we enter 33 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(72,22,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>if we enter 31 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(73,23,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>a  pop up window will appear,if we enter 33 in it,it will show a msg  &quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantitet&quot;</p>',1,1),(74,24,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>if we enter 30 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(75,25,'<p>select &Auml;tg&auml;rd : Okaforhandsorder</p>','<p>if we enter 40 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(76,26,'<p>select &Auml;tg&auml;rd : Okaforhandsorder</p>','<p>if we enter 30 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(77,27,'<p>For product 2(Brother Ink Jet Cartridge)</p>\r\n<p>select&nbsp; Visa : Alla</p>\r\n<p>&nbsp;</p>','<p>The Sales Orders for test are showed</p>',1,1),(78,28,'<p>select  	       &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>a pop up window will appear,if we enter 6 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(79,29,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>if we enter 4&nbsp; in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(80,30,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>a pop up window will appear,if we enter 6 in it,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(81,31,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(82,32,'<p>select &Auml;tg&auml;rd : Okaforhandsorder</p>','<p>if we enter 10 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(83,33,'<p>select &Auml;tg&auml;rd : Okaforhandsorder</p>','<p>if we enter 3 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(84,34,'<p>Login to vTiger Portal(contact 2)(account 2)</p>\r\n<p>&nbsp;</p>','<p>Start Screen</p>',1,1),(85,35,'<p>&nbsp;Select Sales-&gt;Sales Order</p>','<p>&nbsp;Sales Order screen with list of Sales Orders</p>',1,1),(86,36,'<p>For product (Vtiger 50 Users Pack)</p>\r\n<p>select Visa : Alla</p>','<p>The Sales Orders for test are showed</p>',1,1),(87,37,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>a pop up window will appear,if we enter 6 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(88,38,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Avropa</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(89,39,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>a pop up window will appear,if we enter 6 in it,it will show a msg&quot;Antalet f&aring;r inte &ouml;verstiga resterande kvantite&quot;</p>',1,1),(90,40,'<p>select &Auml;tg&auml;rd :&nbsp;&nbsp; Frislapp</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(91,41,'<p>select &Auml;tg&auml;rd : Okaforhandsorder</p>','<p>if we enter 6 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(92,42,'<p>select &Auml;tg&auml;rd : Okaforhandsorder</p>','<p>if we enter 4 in it,data will be submitted,it will show a msg &quot;Klicka p&aring; tillbaka f&ouml;r att g&aring; tillbaks till sidan f&ouml;r avrop&quot;</p>',1,1),(101,1,'<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Login to vTiger</p>','<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Start screen</p>',1,1),(102,2,'<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Select Sales-&gt;Sales Order</p>','<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Sales Order screen with list of Sales Orders</p>',1,1),(103,3,'<p>Click in + for adding new Sales Order</p>','<p>Creating New Sales Order screen</p>',1,1),(104,4,'<p>Enter Subject &quot;ESS1-Created&quot; as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store2&quot;<br />\r\nSelect Status Created<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;abc dummy&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(105,5,'<p>Select Sales-&gt;Sales Order</p>','<p>Sales Order screen with list of Sales Orders<br />\r\n&nbsp;</p>',1,1),(106,6,'<p>Click in + for adding new Sales Order(for approving ESS1)</p>','<p>Creating New Sales Order screen</p>',1,1),(107,7,'<p>Enter Subject \'ESS1-Approved \' as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store2&quot;<br />\r\nSelect Status &quot;Approved&quot;<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;abc dummy&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is Approved<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(108,8,'<p>Select Sales-&gt;Sales Order</p>','<p>Sales Order screen with list of Sales Orders</p>',1,1),(109,9,'<p>Click in + for adding new Sales Order</p>','<p>Creating New Sales Order screen</p>',1,1),(110,10,'<p>Enter Subject \'ESS2-Created \' as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store2&quot;<br />\r\nSelect Status &quot;Created&quot;<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;rr&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results<br />\r\n&nbsp;</p>',1,1),(111,11,'<p>Click on the button Duplicate Sales Order(for ESS2-Created)<br />\r\nChange Status to Approved<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(112,12,'<p>We have logged in via asingh with password(ljlDyhmwDOHP) through ssh.</p>','<p>successfully logged in</p>',1,1),(113,13,'<p>Go to the directory </p>\r\n<p>/svn/gom-dev/root-dir/opt/integration-dev/sales-orders</p>','<p>directory opened successfully</p>',1,1),(114,14,'<p>Execute the setup-tables-sh such as <br />\r\n~/svn/gom-dev/root-dir/opt/integration-dev/sales-orders/./setup-tables.sh</p>','<p>successfully executed&nbsp; setup-tables-sh and successfully created related tables and got the msg </p>\r\n<p>&quot;tables created successfully.&quot;<br />\r\n&nbsp;</p>',1,1),(115,15,'<p>We have logged in via asingh with password(ljlDyhmwDOHP) through ssh</p>','<p>successfully logged in</p>',1,1),(116,16,'<p>Go to the directory</p>\r\n<p>/svn/gom-dev/root-dir/opt/integration-dev/sales-orders</p>','<p>directory opened successfully</p>',1,1),(117,17,'<p>Execute the phpcronjob1.sh such as<br />\r\n&nbsp;~/svn/gom-dev/root-dir/opt/integration-dev/sales-orders/./phpcronjob1.sh</p>','<p>got the msg</p>\r\n<p>&quot;successfully inserted&quot; </p>\r\n<p>4 times.<br />\r\n<br />\r\n&nbsp;</p>',1,1),(118,1,'<p>Login to vTiger</p>','<p>Start screen</p>',1,1),(119,2,'<p>Select Sales-&gt;Sales Order</p>','<p>Sales Order screen with list of Sales Orders</p>',1,1),(120,3,'<p>Click in + for adding new Sales Order</p>','<p>Creating New Sales Order screen</p>',1,1),(121,4,'<p>Enter Subject &quot;ESS1-New&quot; as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store1&quot;<br />\r\nSelect Status Created<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;rr&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(122,5,'<p>Select Sales-&gt;Sales Order</p>','<p>Sales Order screen with list of Sales Orders</p>',1,1),(123,6,'<p>Click in + for adding new Sales Order</p>','<p>Creating New Sales Order screen</p>',1,1),(124,7,'<p>Enter Subject \'ESS2-New \' as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store1&quot;<br />\r\nSelect Status &quot;Created&quot;<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;dd&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(125,8,'<p>We have taken SO with account name (store1),product&nbsp; name(Cykel Velobris 21) and Order No. is self generated( ie.&nbsp; BES11) and execute PHP Cron Job 2</p>','<p>PHP Cron Job2 should be successfully executed and SET file should be created.</p>',1,1),(126,9,'<p>Check SET files in folder &quot;CRONJOBfiles&quot;<br />\r\n&nbsp;</p>','<p>All related files should be available.</p>',1,1),(127,10,'<p>Execute the SET files.</p>','<p>Error should come as Account name and Product name is mismatching the given criteria of being numeric.</p>\r\n<p>Note:(also less than 6 digits testcases cannot be made as Account name and Product name have default values)</p>',1,1),(128,11,'<p>We have taken SO with account name (store1),product&nbsp; name(Cykel Velobris 21) and Order No. is self generated( ie.&nbsp;&nbsp; BES12)<br />\r\nand execute PHP Cron Job 2</p>','<p>PHP Cron Job2 should be successfully executed and SET file should be created.<br />\r\n&nbsp;</p>',1,1),(129,12,'<p>check SET files in folder &quot;CRONJOBfiles&quot;</p>','<p>All related files should be available.</p>',1,1),(130,13,'<p>Execute the SET files.</p>','<p>Error should come as Account name and Product name is mismatching the given criteria of being numeric.<br />\r\n<br />\r\nNote:(also less than 6 digits testcases cannot be made as Account name and Product name have default values) <br />\r\n<br />\r\n&nbsp;</p>',1,1),(264,13,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.<br />\r\n&nbsp;</p>',1,1),(262,11,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(263,12,'<p>Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated <br />\r\n&nbsp;</p>',1,1),(260,9,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(261,10,'<p><br />\r\n10. Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated <br />\r\n&nbsp;</p>',1,1),(257,6,'<p>Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(258,7,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(259,8,'<p><br />\r\nFill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(256,5,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(146,1,'<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Login to vTiger</p>','<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Start screen</p>',1,1),(147,2,'<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Select Sales-&gt;Sales Order</p>','<p>&nbsp;</p>\r\n<p style=\"margin-bottom: 0.2in\">Sales Order screen with list of Sales Orders</p>',1,1),(148,3,'<p>Click in + for adding new Sales Order</p>','<p>Creating New Sales Order screen</p>',1,1),(149,4,'<p>Enter Subject &quot;ESS1-Created&quot; as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store2&quot;<br />\r\nSelect Status Created<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;abc dummy&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(150,5,'<p>Select Sales-&gt;Sales Order</p>','<p>Sales Order screen with list of Sales Orders<br />\r\n&nbsp;</p>',1,1),(151,6,'<p>Click in + for adding new Sales Order(for approving ESS1)</p>','<p>Creating New Sales Order screen</p>',1,1),(152,7,'<p>Enter Subject \'ESS1-Approved \' as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store2&quot;<br />\r\nSelect Status &quot;Approved&quot;<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;abc dummy&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is Approved<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(153,8,'<p>Select Sales-&gt;Sales Order</p>','<p>Sales Order screen with list of Sales Orders</p>',1,1),(154,9,'<p>Click in + for adding new Sales Order</p>','<p>Creating New Sales Order screen</p>',1,1),(155,10,'<p>Enter Subject \'ESS2-Created \' as Subject<br />\r\nClick on + at Account Name and choose Account &quot;Store2&quot;<br />\r\nSelect Status &quot;Created&quot;<br />\r\nScroll down to Item Details and click on Select product icon<br />\r\nSelect product &quot;Cykel Velobris 21&quot;<br />\r\nSet quantity to one<br />\r\nSet Billing address to -&quot;rr&quot;<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results<br />\r\n&nbsp;</p>',1,1),(156,11,'<p>Click on the button Duplicate Sales Order(for ESS2-Created)<br />\r\nChange Status to Approved<br />\r\nClick on Save</p>','<p>A new Sales Order is created<br />\r\nRecord the New Sales Order Number in the test results</p>',1,1),(157,12,'<p>We have logged in via asingh with password(ljlDyhmwDOHP) through ssh.</p>','<p>successfully logged in</p>',1,1),(158,13,'<p>Go to the directory </p>\r\n<p>/svn/gom-dev/root-dir/opt/integration-dev/sales-orders</p>','<p>directory opened successfully</p>',1,1),(159,14,'<p>Execute the setup-tables-sh such as <br />\r\n~/svn/gom-dev/root-dir/opt/integration-dev/sales-orders/./setup-tables.sh</p>','<p>successfully executed&nbsp; setup-tables-sh and successfully created related tables and got the msg </p>\r\n<p>&quot;tables created successfully.&quot;<br />\r\n&nbsp;</p>',1,1),(160,15,'<p>We have logged in via asingh with password(ljlDyhmwDOHP) through ssh</p>','<p>successfully logged in</p>',1,1),(161,16,'<p>Go to the directory</p>\r\n<p>/svn/gom-dev/root-dir/opt/integration-dev/sales-orders</p>','<p>directory opened successfully</p>',1,1),(162,17,'<p>Execute the phpcronjob1.sh such as<br />\r\n&nbsp;~/svn/gom-dev/root-dir/opt/integration-dev/sales-orders/./phpcronjob1.sh</p>','<p>got the msg</p>\r\n<p>&quot;successfully inserted&quot; </p>\r\n<p>4 times.<br />\r\n<br />\r\n&nbsp;</p>',1,1),(163,18,'<p>We have logged in via asingh with wrong password through ssh.</p>','<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; An error should be written to syslog.</p>',1,1),(165,14,'<p>We have logged in via asingh with wrong password through ssh.</p>','<p>&nbsp;&nbsp; An error should be written to syslog.</p>',1,1),(166,1,'<p>We have to check the FTP connection.</p>','<p>It must show the message &quot;the FTP is connected&quot; or &quot;the FTP is not connected.&quot;</p>',1,1),(167,2,'<p>If the FTP server is not connected.</p>','<p>An error should be written to syslog.</p>',1,1),(168,4,'<p>We have to check whether the connection for Rabbit MQ server is available or not available.</p>','<p>The connection for Rabbit MQ server should be available.</p>\r\n<p>If not available then an error should be written to syslog.</p>',1,1),(169,7,'<p>We have to check whether the connection for Interface database is available or not available.<br />\r\n&nbsp;</p>','<p>The connection for Interface database server should be available.</p>\r\n<p>&nbsp;</p>',1,1),(170,10,'<p>We should check that all conditions are working fine.</p>','<p>We should get the message Go to the next system.</p>',1,1),(171,11,'<p>We have to fetch the data from interface table</p>\r\n<p>salesorder_msg&nbsp; where the status is zero.</p>','<p>running of the script should be continued if record found otherwise the script should be stopped.</p>',1,1),(172,12,'<p>We have to check whether there is any error for fetching the record from the database.If error exists.</p>','<p>An error should be written to syslog.</p>',1,1),(173,13,'<p>We have to fetch the file and upload it&nbsp; to the server.</p>','<p>We should get the message &quot;file uploaded successfully&quot;.</p>',1,1),(174,14,'<p>If fetched file not uploaded to the server.</p>','<p>An error should be written to syslog.</p>',1,1),(175,15,'<p>We should check the file is uploaded successfully on FTP server and must recieve the message from Rabbit MQ server.</p>','<p>We should get the message &quot; message recieved successfully&quot; and also the message queue of Rabbit MQ server should be decreased.</p>',1,1),(176,16,'<p>We should check the file is uploaded successfully on FTP server but Rabbit MQ server is not responding .</p>','<p>The file should be uploaded on the FTP server and&nbsp; the local server should be&nbsp; rolled back.</p>\r\n<p>An error should be written to syslog.</p>',1,1),(177,3,'<p>If the FTP server is connected.</p>','<p>Everyhing should be ok and an error should not be written to syslog.</p>',1,1),(178,5,'<p>If connection for Rabbit MQ server is available.</p>','<p>Everyhing should be ok and an error should not be written to syslog.</p>\r\n<p>&nbsp;</p>',1,1),(179,6,'<p>If connection for Rabbit MQ server is not available.</p>','<p>An error should be written to syslog.</p>',1,1),(180,8,'<p>If connection for Interface database is available.</p>','<p>Everything should be ok and error should not be written to syslog.</p>',1,1),(181,9,'<p>If connection for Interface database is not available.</p>','<p>An error should be written to syslog.<br />\r\n&nbsp;</p>',1,1),(182,17,'<p>After step 15 check whether the corresponding database is updated successfully. </p>','<p>We should get the message &quot;database updated successfully&quot;.</p>',1,1),(183,18,'<p>If the database is not updated successfully.</p>','<p>All the previous transactions should be rolled back and an error message should be written to syslog.</p>',1,1),(193,1,'<p>Login to Portal</p>','<p>Start screen</p>',1,1),(194,2,'<p>Click on survey(Kontrollbesiktning)</p>','<p>Survey page should be displayed.</p>',1,1),(195,3,'<p>select date + year=2012 + month=september + Trailor = AX009 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed.</p>',1,1),(196,4,'<p>Select ID= TT182&nbsp; +&nbsp; Transportor= Exceed99 +we click on the&nbsp; Markus Jane</p>','<p>Ticket information correspondence to ID=T182 should be displayed.</p>',1,1),(197,5,'<p>Click on List of Survey</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(198,6,'<p>select date + year=2012 + month= August + Trailor = AX009 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed.</p>',1,1),(199,7,'<p>Select ID= 1&nbsp; +&nbsp; Transportor= Exceed99 +we click on the&nbsp; Markus Jane</p>','<p>Ticket information correspondence to ID= 1 should be displayed.</p>',1,1),(200,8,'<p>Click on List of Survey</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(201,9,'<p>select date + year=2012 + month= August + Trailor = AXT0010 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(202,10,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(203,11,'<p>select date + year=2012 + month= August + Trailor = AXT0013 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(204,12,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(205,13,'<p>select date + year=2012 + month= September + Trailor = AXT0010 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(206,14,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(207,15,'<p>select date + year=2012 + month= September + Trailor = AXT0013 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(208,16,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(209,17,'<p>select date + year=2011 + month= September + Trailor = AXT009 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(210,18,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(211,19,'<p>select date + year=2011 + month= September + Trailor = AXT0010 + select radio button &ldquo;drift&rdquo;</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(212,20,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(213,21,'<p>select date + year=2011 + month= September + Trailor = AXT0013 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(214,22,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(215,23,'<p>select date + year=2011 + month= August + Trailor = AXT009 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(216,24,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(217,25,'<p>select date + year=2011 + month= August + Trailor = AXT0010 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(218,26,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(219,27,'<p>select date + year=2011 + month= August + Trailor = AXT0013 + select radio button &ldquo;drift&rdquo;.</p>','<p>&ldquo;Support&auml;rende Lista &ldquo; should be displayed (no data available).</p>',1,1),(220,28,'<p>Click on Kontrollbesiktning</p>','<p>Again we should move back to Kontrollbesiktning page.</p>',1,1),(234,1,'<p>Login to portal</p>','<p>Start screen</p>',1,1),(235,2,'<p>Click on survey(Kontrollbesiktning)</p>','<p>Survey page should be displayed.</p>',1,1),(236,3,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.<br />\r\n&nbsp;</p>',1,1),(237,4,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp; Ticket should be generated</p>',1,1),(238,5,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(239,6,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(240,7,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(241,8,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(242,9,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(243,10,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(244,11,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(245,12,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated&nbsp;</p>',1,1),(246,13,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(247,14,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated&nbsp;</p>',1,1),(248,15,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(249,16,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(250,17,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(251,18,'<p>Fill the form Title= No damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated&nbsp;</p>',1,1),(252,1,'<p>Login to portal</p>','<p>Start screen</p>',1,1),(253,2,'<p>Click on survey(Kontrollbesiktning)</p>','<p>Survey page should be displayed.</p>',1,1),(254,3,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(255,4,'<p>Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(265,14,'<p>Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(266,15,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(267,16,'<p>Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>&nbsp;Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(268,17,'<p>&nbsp;Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(269,18,'<p>Fill the form Title= No Trailor damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=NO&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=NO<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(272,1,'<p>Login to portal </p>','<p>Start screen</p>',1,1),(273,2,'<p>Click on survey(Kontrollbesiktning)</p>','<p>Survey page should be displayed.</p>',1,1),(274,3,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(275,4,'<p>Fill the form Title=Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(276,5,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.<br />\r\n&nbsp;</p>',1,1),(277,6,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>&nbsp;Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(278,7,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(279,8,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(280,9,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(281,10,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(282,11,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(283,12,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(284,13,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(285,14,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(286,15,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(287,16,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(288,17,'<p>&nbsp;Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should open.</p>',1,1),(289,18,'<p>Fill the form Title= Trailor One damage + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated </p>',1,1),(293,1,'<p>Login to portal&nbsp;&nbsp; </p>','<p>Start screen</p>',1,1),(294,2,'<p>Click on survey(Kontrollbesiktning)</p>','<p>Survey page should be displayed.</p>',1,1),(295,3,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(296,4,'<p>&nbsp;Fill the form Title=Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated<br />\r\n&nbsp;</p>',1,1),(297,5,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(298,6,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(299,7,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(300,8,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(301,9,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(302,10,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(303,11,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(304,12,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(305,13,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(306,14,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(307,15,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(308,16,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(309,17,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed<br />\r\n&nbsp;</p>',1,1),(310,18,'<p>Fill the form Title= Trailor ten damages + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(313,1,'<p>Login to portal&nbsp; </p>','<p>Start screen</p>',1,1),(314,2,'<p>Click on survey(Kontrollbesiktning)</p>','<p>Survey page should be displayed.</p>',1,1),(315,3,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(316,4,'<p>Fill the form Title=Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated<br />\r\n&nbsp;</p>',1,1),(317,5,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(318,6,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed</p>',1,1),(319,7,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)</p>',1,1),(320,8,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(321,9,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(322,10,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(323,11,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>&nbsp;Ticket information page should be displayed.</p>',1,1),(324,12,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)<br />\r\n&nbsp;</p>',1,1),(325,13,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(326,14,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(327,15,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(328,16,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed.</p>',1,1),(329,17,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)</p>',1,1),(330,18,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(331,19,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Bakre(Back) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(332,20,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(333,21,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed.</p>',1,1),(334,22,'<p>&nbsp;Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)</p>',1,1),(335,23,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(336,24,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(337,25,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(338,26,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed.</p>',1,1),(339,27,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)</p>',1,1),(340,28,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(341,29,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Big Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(342,30,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(343,31,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed.</p>',1,1),(344,32,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)</p>',1,1),(345,33,'<p>Click on Create new Trouble ticket</p>','<p>Create new Trouble ticket page should be displayed</p>',1,1),(346,34,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=Trailersidor + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(347,35,'<p>We again click on survey</p>','<p>Survey page should be displayed.</p>',1,1),(348,36,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed.</p>',1,1),(349,37,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)<br />\r\n&nbsp;</p>',1,1),(350,38,'<p>&nbsp;Click on Create new Trouble ticket</p>','<p>&nbsp;Create new Trouble ticket page should be displayed</p>',1,1),(351,39,'<p>Fill the form Title= Trailor repair + TrailerId= VVS10001 + sealed=Yes + Straps=34<br />\r\n&nbsp;&nbsp; Position On Trailer For Damage=Framside(Frontside) + &quot;Damage Reported=Yes&quot; + Ticket Category=Small Problem<br />\r\n&nbsp;&nbsp; + Location For Damage Report=Delhi + Plates=12 + Type Of Damage=D&amp;ouml;rrar + Driver Caused Damage=Yes<br />\r\n&nbsp;&nbsp; + Submit</p>','<p>Data should be successfully inserted into tables<br />\r\n&nbsp;&nbsp; Ticket should be generated</p>',1,1),(352,40,'<p>We again click on survey</p>','<p>Survey page should be displayed.<br />\r\n&nbsp;</p>',1,1),(353,41,'<p>Click on the Account against new Trouble Ticket generated</p>','<p>Ticket information page should be displayed.</p>',1,1),(354,42,'<p>Click on Mark damage repaired</p>','<p>Status of damage= closed (should be displayed for the repaired ticket)</p>',1,1),(362,1,'<p>Try to login to app </p>','<p>The message should appear to user to import public-private key pair into app by some means like clicking on some link or by SMS.</p>',1,1),(365,1,'<p>Keep username field blank</p>','',1,1),(366,2,'<p>Enter some password</p>','',1,1),(367,3,'<p>Tap on login button</p>','<p>The error message should appear promting &quot;enter username&quot;</p>',1,1),(370,1,'<p>Keep password field blank</p>','',1,1),(371,2,'<p>Enter username</p>','',1,1),(372,3,'<p>Tap on login button</p>','<p>The error message should appear promting &quot;enter password&quot;</p>',1,1),(375,1,'<p>Enter incorrect username</p>','',1,1),(376,2,'<p>enter correct password</p>','',1,1),(377,3,'<p>Tap on login</p>','<p>The error message should appear promting &quot;username or password field is incorrect&quot;</p>',1,1),(380,1,'<p>Enter correct username</p>','',1,1),(381,2,'<p>Enter incorrect password</p>','',1,1),(382,3,'<p>Tap on login</p>','<p>The error message should appear promting &quot;username or password field is incorrect&quot;</p>',1,1),(385,1,'<p>Enter correct username</p>','',1,1),(386,2,'<p>Enter correct password</p>','',1,1),(387,3,'<p>Tap on Login</p>','<p>On successful login&nbsp; the Home screen of app should appear.</p>',1,1),(390,1,'<p>On home screen tap on Logout button</p>','<p>The user should get logged out of app.</p>',1,1),(393,1,'<p>Tap on reset button</p>','<p>The home screen should reset to its original state.</p>',1,1),(396,1,'<p>Select trailer Id at survey page</p>','<p>The Damages Button should enabled</p>',1,1),(399,1,'<p>On home screen tap on Damages Button</p>','',1,1),(400,2,'<p>Tap on report a new damage</p>','',1,1),(401,3,'<p>Tap on type</p>','<p>The list of damage types should appear.</p>',1,1),(404,1,'<p>In damage details tap on position</p>','<p>the message should appear promting &quot; please select type &quot;</p>',1,1),(407,1,'<p>Report A damage</p>','<p>It should appear in Reporting Damage</p>',1,1),(408,2,'<p>Now report a similar damage with added image</p>','<p>it should update earlier matching ticket with images in Reporting damage section.</p>',1,1),(411,1,'<p>In damage details select type and then tap on position</p>','<p>The list should appear according to type mentioned in requirement document.</p>',1,1),(412,2,'<p>Do above step for each item in type list</p>','',1,1),(417,1,'<p>In suervey Tap on ID</p>','<p>List containing trailer\'s Id should appear.</p>',1,1),(420,1,'<p>In survey tap on place</p>','<p>List containing places should appear.</p>',1,1),(425,1,'<p>In Damage Images Tap On Add a new image</p>','<p>Various option for adding image should appear like camera, photo galary etc.</p>',1,1),(428,1,'<p>In Previously Reported Damages tap on any damage</p>','<p>&Igrave;t should show the damage details and attached damage images</p>',1,1),(431,1,'<p>Tap on submit button</p>','<p>It should start the process for submitting damages to&nbsp; the server and once that over those should appear in previously reported damages</p>',1,1),(443,1,'<p>start app</p>','<p>If user is already logged in then home (survey) screen should be displayed otherwise login screen should be displayed.</p>',1,1),(444,2,'<p>user selects the trailer type. tap on id.</p>','<p>list containing trailer\'s id&nbsp; should be displayed.</p>',1,1),(445,3,'<p>user tap on one of id</p>','<p>that id should appear in ID&nbsp;field. Damages button should be enabled.</p>',1,1),(446,4,'<p>now user taps on button Damages</p>','<p>screen showing list of damages already submitted which are open should appear with \'Report a new damage\' button</p>',1,1),(447,6,'<p>In&nbsp; \'Damage details\' user tap on type</p>','<p>List containing various types of damages should appear.</p>',1,1),(448,7,'<p>user taps on one of type</p>','<p>that should appear in \'Type\' field</p>',1,1),(449,8,'<p>User Tap on \'position\' </p>','<p>List related to above selected type should appear.</p>',1,1),(450,9,'<p>user tap on one of position</p>','<p>that should appear in \'position\' field. done button should enabled.</p>',1,1),(451,10,'<p>If user wants to add images then he/she will tap on \'Add a new image button\'</p>','<p>Various option for selecting image should appear.</p>',1,1),(452,11,'<p>user uses those option and selects image</p>','<p>that image should appear in \'Damage details\' screen.</p>',1,1),(453,12,'<p>If user wants to add more images, Then he will perform step 9 and 10.</p>','<p>then Image list should appear in \'Damage details\' screen.</p>',1,1),(454,13,'<p>user tap on \'done\' button</p>','<p>Above Damage should appear in \'Reporting Damage\' </p>',1,1),(455,14,'<p>User tap on submit button</p>','<p>the \'Reporting Damage\' should Reported and it should appear in \'Previously Reported Damages\' list.</p>',1,1),(458,1,'<p>start app</p>','<p>If user is already logged in then home (survey) screen should be displayed otherwise login screen should be displayed.</p>',1,1),(459,2,'<p>user selects the trailer type. tap on id.</p>','<p>list containing trailer\'s id&nbsp; should be displayed.</p>',1,1),(460,3,'<p>user tap on one of id</p>','<p>that id should appear in ID&nbsp;field. Damages button should be enabled.</p>',1,1),(461,4,'<p>now user taps on button Damages</p>','<p>screen showing list of damages already submitted which are open should appear with \'Report a new damage\' button</p>',1,1),(462,6,'<p>In&nbsp; \'Damage details\' user tap on type</p>','<p>List containing various types of damages should appear.</p>',1,1),(463,7,'<p>user taps on one of type</p>','<p>that should appear in \'Type\' field</p>',1,1),(464,8,'<p>User Tap on \'position\' </p>','<p>List related to above selected type should appear.</p>',1,1),(465,9,'<p>user tap on one of position</p>','<p>that should appear in \'position\' field. done button should enabled.</p>',1,1),(466,10,'<p>If user wants to add images then he/she will tap on \'Add a new image button\'</p>','<p>Various option for selecting image should appear.</p>',1,1),(467,11,'<p>user uses those option and selects image</p>','<p>that image should appear in \'Damage details\' screen.</p>',1,1),(468,12,'<p>If user wants to add more images, Then he will perform step 9 and 10.</p>','<p>then Image list should appear in \'Damage details\' screen.</p>',1,1),(469,13,'<p>user tap on \'done\' button</p>','<p>Above Damage should appear in \'Reporting Damage\'</p>',1,1),(470,14,'<p>do above 5 to 13 steps 10 times</p>','',1,1),(472,5,'<p>User tap on \'Report a new damage\'</p>','<p>screen for entering damage details should appear.</p>',1,1),(471,15,'<p>User tap on submit button</p>','<p>The \'Reporting Damage\' should reported and it should appear in \'previously Reported damages\' list</p>',1,1),(473,5,'<p>user tap on \'Report a new damage\'</p>','<p>screen for entering damage details should appear.</p>',1,1),(474,1,'<p>On server side change status of damage ticket with \'closed\'</p>','',1,1),(475,2,'<p>start app</p>','<p>If user is already logged in then home (survey) screen should be displayed otherwise login screen should be displayed.</p>',1,1),(476,3,'<p>user selects Trailer type. and tap on \'ID\'</p>','<p>list containing trailer\'s id&nbsp; should be displayed.</p>',1,1),(477,5,'<p>tap on \'Places\'</p>','<p>list containing places should be appear.</p>',1,1),(478,4,'<p>user tap on id of trailer whose ticked is closed</p>','<p>that id should appear in ID&nbsp;field. Damages button should be enabled.</p>',1,1),(481,1,'<p>On server side change status of trailer to \'out of service\'</p>','',1,1),(482,2,'<p>start app</p>','<p>If user is already logged in then home (survey) screen should be displayed otherwise login screen should be displayed.</p>',1,1),(483,3,'<p>user selects Trailer type. and tap on \'ID\'</p>','<p>list containing trailer\'s id&nbsp; should not display the above trailer which is out of service</p>',1,1),(487,7,'<p>user select&nbsp; \'sealed\' as yes or no</p>','<p>if no \'trailer inventary \' should appear.</p>',1,1),(486,6,'<p>tap on one of place</p>','<p>that place should appear in \'places\' field.</p>',1,1),(488,8,'<p>user tap on submit button</p>','<p>survey tickect should be submitted to server.</p>',1,1),(491,1,'<p>On server side change status of ticket for particular trailer \'closed\'</p>','',1,1),(492,2,'<p>start app</p>','<p>If user is already logged in then home (survey) screen should be displayed otherwise login screen should be displayed.</p>',1,1),(493,3,'<p>user selects Trailer type. and tap on \'ID\'</p>','<p>list containing trailer\'s id&nbsp; should be displayed. </p>',1,1),(494,4,'<p>Tap on above used particular trailer id</p>','<p>that id should appear in \'Id\' field.&nbsp;</p>',1,1),(495,5,'<p>tap on \'Danmages\'</p>','<p>screen containing list of \'previously reported damages\' should not contain the ticket which is above closed</p>',1,1),(501,1,'<p>tap on link or copy and paste it in browser\'s address bar</p>','<p>the login screen of the damage claim should appear.</p>',1,1),(497,1,'<p>tap on submit button</p>','<p>Survey&nbsp; should be submitted to the server.</p>',1,1),(549,1,'Login to vTiger','Home Screen.',1,1),(550,2,'Select menu Sales/SalesOrder.','SalesOrder list with previously added sales orders if any.',1,1),(551,3,'Click on the + (Create New SalesOrder) button to add the new SalesOrder.','Sales order add new form.',1,1),(552,4,'<p>Fill the required fields:</p>\r\n<p>Subject: CIKABNFS-10</p>\r\n<p>Quote Name: CIKABNFS-9</p>\r\n<p>Organisation Name: TEST</p>\r\n<p>Contact Name: Jonas Colmsjo</p>\r\n<p>Click on the product icon and select the 202035 (SPARKCYKEL ROSA) product</p>\r\n<p>Quantity: 10</p>\r\n<p>Click on Save button.</p>\r\n','<p>On selecting the Quote, all products or selected quote will be added automatically in the sales order.</p>\r\n<p>A new sales order will be created and it will display the detail view of the sales order.</p>\r\n<p>The selected quote will be marked, <b>Accepted</b> automatically.</p>',1,1),(553,5,'<p>Login to the bikerportal with the selected contact.</p>\r\n<p>Username: jonas.colmsjo@gizur.com</p>\r\n<p>Password: homeend01</p>','Home screens with the enabled modules tabs.',1,1),(554,7,'Click on the CikabTroubleTicket tab.','<p>List of products with the Order, Sale order quantity.</p>\r\n<p>In this case we will see the following result</p>\r\n<table cellspacing=\"0\" cellpadding=\"5\" border=\"1\" align=\"center\"><tbody><tr align=\"center\">\r\n	      <td class=\"detailedViewHeader\">Product Id</td>\r\n	      <td class=\"detailedViewHeader\">Product Name</td>\r\n	      <td class=\"detailedViewHeader\">Description</td>\r\n	      <td class=\"detailedViewHeader\">Order</td>\r\n	      <td class=\"detailedViewHeader\">Sale Order</td>\r\n	      <td class=\"detailedViewHeader\">Left Order</td>\r\n	       <td class=\"detailedViewHeader\">Action</td>\r\n	        </tr><tr class=\"dvtLabel\"> <td>PRO1</td><td>202035</td>\r\n	        <td>SPARKCYKEL ROSA</td>\r\n	        <td>10</td> \r\n	       <td>10</td>\r\n	       <td>0</td>\r\n	          <td></td>\r\n	     </tr> \r\n	   \r\n	 </tbody></table>',1,1),(555,6,'','',1,1),(558,1,'Login to the biker portal.','Home screen with the enabled module tabs.',1,1),(559,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(560,3,'Select the call off from the action select.','A dialog box will be opened.',1,1),(561,4,'Enter the value greater than the left order value and press OK.','An alert with an error message \'The number box should less than balance quantity\' will be displayed.',1,1),(562,5,'Enter the value less than the left value and press OK.','<p>A new sales order will be created and sales order number will be given as output.</p>\r\n<p>Now you can see the sale order value increased by the entered value by clicking on the CikabTroubleTicket tab for the corresponding product.</p>',1,1),(565,1,'Login to the portal.','Home screen with the enabled module tabs.',1,1),(566,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(567,3,'Select the Increase action.','A dialog box will be opened.',1,1),(568,4,'Enter the value 10 and press OK.','A new ticket will be created to increase the selected product with the quantity 10.',1,1),(571,1,'Login to the portal.','Home screen with the enabled module tabs.',1,1),(572,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(573,3,'Select the Release action.','A dialog box will be opened.',1,1),(574,4,'Enter the value 10 and press OK.','<p>A new ticket will be created to decrease the selected product with the quantity 10.</p>\r\n<p>This will result in auto closing the old ticket/tickets with increase request and creating the new tickets for the same product.</p>',1,1),(577,1,'Login to the portal.','Home screen with the enabled module tabs.',1,1),(548,4,'<p>Fill the required fields:</p>\r\n<p>Subject: CIKABNFS-9</p>\r\n<p>Quote Stage: created</p>\r\n<p>Organisation Name: TEST</p>\r\n<p>Contact Name: Jonas Colmsjo</p>\r\n<p>Add the Billing Address and Shipping Address</p>\r\n<p>Click on the product icon and select the 202035 (SPARKCYKEL ROSA) product</p>\r\n<p>Quantity: 10</p>\r\n<p>Click on Save button.</p>\r\n','Detail view of new added quote with the quote number updated.',1,1),(547,3,'Click on the + (Create new Quote) button.','Form to add new Quote.',1,1),(545,1,'Login to the vTiger','Home Screen.',1,1),(546,2,'Select the Sales/Quote menu.','Quote list screen with quotes if any.',1,1),(578,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(579,3,'Select the Release action.','A dialog box will be opened.',1,1),(580,4,'Enter the value 30 and press OK.','<p>A new ticket will be created to decrease the selected product with the quantity 30.</p>\r\n<p>This will result in auto closing the old ticket(s) with increase request.</p>\r\n<p>If balance quantity will be there, a new ticket will be created for the same.</p>',1,1),(583,1,'Login to the portal.','Home screen with the enabled module tabs.',1,1),(584,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(585,3,'Select the Release action.','A dialog box will be opened.',1,1),(586,4,'Enter the value 50 and press OK.','<p>A new ticket will be created to increase the selected product with the quantity 50.</p>\r\n<p>This will result in auto closing the old ticket(s) with decrease request.</p>\r\n<p>In case of balance quantity, a new ticket will be created for the same.</p>',1,1),(589,1,'Login to the portal.','Home screen with the enabled module tabs.',1,1),(590,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(591,3,'Select the Release action.','A dialog box will be opened.',1,1),(592,4,'Enter the value 30 and press OK.','<p>A new ticket will be created to increase the selected product with the quantity 30.</p>\r\n<p>This will result in auto closing the old ticket(s) with decrease request.</p>\r\n<p>In case of balance quantity, a new ticket will be created for the same.</p>',1,1),(595,1,'Login to the portal.','Home screen with the enabled module tabs.',1,1),(596,2,'Click on CikabTroubleTicket.','List of all the products with the order, sale order, left order values and action will be displayed.',1,1),(597,3,'Select the Release action.','A dialog box will be opened.',1,1),(598,4,'Enter the value 30 and press OK.','<p>A new ticket will be created to decrease the selected product with the quantity 30.</p>\r\n<p>This will result in auto closing the old ticket(s) with increase request.</p>\r\n<p>in case of balance quantity, a new ticket will be created for the same.</p>',1,1),(601,1,'Login to vTiger.','vTiger dashboard.',1,1),(602,2,'Click on PRODUCTS tab to go to products module.','Products list, if any.',1,1),(603,3,'Click on + button to a new product.','Create new product form.',1,1),(604,4,'Write PRODUCT-1 in product name field, fill the other details and click on Save button.','Detail view of the product, PRODUCT-1',1,1),(605,5,'Redo the step 3 and 4 to add the second product, PRODUCT-2.','Detail view of the product, PRODUCT-2.',1,1),(606,6,'Click on the Organisation tab, to go the organisation module.','List view of all the organisation, if any.',1,1),(607,7,'Click on the + button to add a new organisation.','Create new organisation form.',1,1),(608,8,'Enter ORGANISATION-1, in organisation name field, fill the other details and click on the save button.','ORGANISATION-1 will be added and detail view will be shown.',1,1),(609,10,'Click on the Quote tab, to go to the Quote module.','List view of all the Quotes.',1,1),(610,11,'Create new Quote by clicking on + button.','Create a new Quote form.',1,1),(611,12,'Enter QUOTE-1, in subject, select the organisation-1, add the PRODUCT-1 with the quantity 100 and PRODUCT-2 with the quantity 100 by clicking on the add product icon. Click on the Save button.','QUOTE-1 will be added and detail view of the Quote-1 will be shown.',1,1),(612,14,'Click on Contacts tab to go to the Contacts module.','List view of contacts.',1,1),(613,15,'Click on + button to add a new contact.','Create a new contact form.',1,1),(614,16,'Add the CONTACT-1 in the last name, Select the ORGANISATION-1, and add the email. You must check the checkbox in case this is the portal user. Click on the Save button.','CONTACT-1 will be added with the auto generated password and detail view will be shown.',1,1),(615,18,'Get the password for the CONTACT-1 and login to the portal.','Screen with the enabled modules tabs will be shown.',1,1),(616,19,'Click on the CikabTroubleTicket module.','<p>Check the PRODUCT-1 is there with the order quantity 100, sale order quantity 0 and available 100.</p>\r\n<p>Check the PRODUCT-2 is there with the order quantity 100, sale order quantity 0 and available 100.</p>',1,1),(617,22,'Do a decrease by 10 for PRODUCT-1.','<p>A ticket will be created for the decrease request.</p>\r\n<p>Check CONTACT-1\'s increase by 10 ticket is closed.</p>\r\n<p>Check CONTACT-2\'s decrease by 10 ticket is closed.</p>\r\n<p>Check QUOTE-2, PRODUCT-1 order quantity is 90, sale order 0 and available is 90.</p>\r\n<p>Check QUOTE-1, PRODUCT-1 order quantity is 110, sale order 0 and available is 110.</p>\r\n<p>Check QUOTE-1, PRODUCT-2 order quantity is 100, sale order 0 and available is 100.</p>',1,1),(622,20,'Do a increase by 10 for PRODUCT-1.','<p>A ticket will be created for the increase request.</p>\r\n<p>Check there should be no effect on QUOTE-1 and QUOTE-2</p>',1,1),(618,9,'Follow the step 7 and 8 to add the ORGANISATION-2.','Detail view of ORGANISATION-2 will be shown.',1,1),(619,13,'Follow the step 11 and 12 to add the QUOTE-2, for ORGANISATION-2 for the PRODUCT-1 and set the quantity 100.','QUOTE-2 will be added.',1,1),(620,17,'Follow the step 15 and 16 to the CONTACT-2, and select the ORGANISATION-2.','CONTACT-2 will be added.',1,1),(621,21,'Logout with CONTACT-1 and Follow the step 18 and 19 for the CONTACT-2.','Check the PRODUCT-1 is there with the order quantity 100, sale order quantity 0 and available 100.',1,1),(623,23,'Do a decrease by 10 for PRODUCT-1.','<p>Check a new ticket is created to decrease by 10 with open status for CONTACT-2.</p>\r\n<p>Check there is no effect on both QUOTEs. i.e.</p>\r\n<p>\r\nCheck QUOTE-2, PRODUCT-1 order quantity is 90, sale order 0 and available is 90.\r\n</p>\r\n<p>\r\nCheck QUOTE-1, PRODUCT-1 order quantity is 110, sale order 0 and available is 110.\r\n</p><p>\r\nCheck QUOTE-1, PRODUCT-2 order quantity is 100, sale order 0 and available is 100.</p>',1,1),(624,24,'Logout and loin as CONTACT-1.','Screen with the enabled modules tabs will be shown.',1,1),(625,25,'Click on the CikabTroubleTicket module.','<p>Check the PRODUCT-1 is there with the order quantity 110, sale order quantity 0 and available 110.</p>\r\n<p>Check the PRODUCT-2 is there with the order quantity 100, sale order quantity 0 and available 100.</p>',1,1),(626,26,'Do a increase by 10 for PRODUCT-1.',' 	\r\n<p>A new ticket will be created for the increase by 10 request.</p>\r\n\r\n<p>Check CONTACT-2\'s decrease by 10 ticket is closed.</p>\r\n\r\n<p>Check CONTACT-2\'s increase by 10 (current ticket) ticket is closed.</p>\r\n\r\n<p>Check QUOTE-2, PRODUCT-1 order quantity is 80, sale order 0 and available is 80.</p>\r\n\r\n<p>Check QUOTE-1, PRODUCT-1 order quantity is 120, sale order 0 and available is 120.</p>\r\n\r\n<p>Check QUOTE-1, PRODUCT-2 order quantity is 100, sale order 0 and available is 100.</p>',1,1);
/*!40000 ALTER TABLE `tcsteps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tcversions`
--

DROP TABLE IF EXISTS `tcversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tcversions` (
  `id` int(10) unsigned NOT NULL,
  `tc_external_id` int(10) unsigned DEFAULT NULL,
  `version` smallint(5) unsigned NOT NULL DEFAULT '1',
  `layout` smallint(5) unsigned NOT NULL DEFAULT '1',
  `status` smallint(5) unsigned NOT NULL DEFAULT '1',
  `summary` text,
  `preconditions` text,
  `importance` smallint(5) unsigned NOT NULL DEFAULT '2',
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updater_id` int(10) unsigned DEFAULT NULL,
  `modification_ts` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_open` tinyint(1) NOT NULL DEFAULT '1',
  `execution_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 -> manual, 2 -> automated',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tcversions`
--

LOCK TABLES `tcversions` WRITE;
/*!40000 ALTER TABLE `tcversions` DISABLE KEYS */;
INSERT INTO `tcversions` VALUES (4,1,1,1,1,'<p><strong>Test</strong></p>\r\n<p>What to perform</p>\r\n<p><strong>Expected result</strong></p>\r\n<p>What the result should be</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>','',2,2,'2012-03-06 10:12:42',2,'2012-03-06 10:14:58',1,1,1),(6,2,1,1,1,'<p><strong>Test</strong></p>\r\n<p>What to test</p>\r\n<p><strong>Expected result</strong></p>\r\n<p>What the result should be</p>\r\n<p>&nbsp;</p>','',2,2,'2012-03-06 10:16:57',NULL,'0000-00-00 00:00:00',1,1,1),(13,1,1,1,1,'<p><strong>Test data</strong></p>\r\n<p>Account: test</p>\r\n<p>Product: Cykel Velobris 21&quot;</p>\r\n<p>Contact / login to the customer portal: test@gizur.com/<strong style=\"color: rgb(153, 0, 0); font-family: arial, sans-serif; background-color: rgb(226, 226, 225); \">&nbsp;tpc00wer&nbsp;</strong></p>\r\n<p><strong>Test</strong>&nbsp;</p>\r\n<p><span style=\"background-color: rgb(238, 238, 238); font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; \">1. Create four sales orders for one Account and one Product. Set the quantity to 2. There should be one sales order each with status:</span></p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \"><span style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Arial; \">* Created</span></p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \"><span style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Arial; \">* Approved</span></p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \"><span style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Arial; \">* Delivered</span></p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \"><span style=\"margin-top: 0px; margin-right: 0px; margin-bottom: 0px; margin-left: 0px; padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; font-family: Arial; \">* Cancelled</span></p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">2. Create six quotes for the same product and account that the sales order was created for. Set the quantity to 10. Create one quote of each status:</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">* Created</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">* Delivered</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">* Reviewed</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">* Accepted</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">* Rejected</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">3. Login to the portal. Check the Best&auml;llnings screen.</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">&nbsp;</p>\r\n<p><strong>Expected result&nbsp;</strong></p>\r\n<p>In vTiger there should be:</p>\r\n<p><span style=\"background-color: rgb(238, 238, 238); font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; \">* 5 new sales orders </span>&nbsp;</p>\r\n<p><span style=\"background-color: rgb(238, 238, 238); font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; \">* 6 new quotes&nbsp;</span></p>\r\n<p>In there portal there should be:</p>\r\n<p><span style=\"background-color: rgb(238, 238, 238); font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; \">There should be one row for the product that the Sales Orders and Quotes were created for.</span></p>\r\n<p>&nbsp;For Product Cykel Velobris 21&quot; should the order column say six and the F&ouml;rhandsorder column 30</p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: left;\"><font face=\"\'Trebuchet MS\', Arial, Verdana, sans-serif\"><br />\r\n</font></p>\r\n<p>&nbsp;</p>','<p>&nbsp;Accounts, Products and Account/Products (assortment) needs to be setup.</p>',2,2,'2012-03-06 10:55:09',2,'2012-03-19 16:03:29',1,1,1),(47,5,1,1,1,'<p><strong>Test data - </strong><span style=\"color: rgb(255, 102, 0); \">SPECIFY THE&nbsp;DATA TO BE USED</span></p>\r\n<p>Account 1:</p>\r\n<p>Account 2:</p>\r\n<p>Product 1:</p>\r\n<p>Product 2:</p>\r\n<p>Make sure that Account 1 and Account 2 both have Product 1 and Product 2 listed under More information-&gt;Products.</p>\r\n<p>Contact 1 (for Account 1):</p>\r\n<p>Contact 2 (for Account 2):</p>\r\n<p>Contact 3 (Central portal user):</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Test</strong></p>\r\n<p>In vTiger:&nbsp;Create Sales Orders for the wo Accounts (stores) above. Create one sales order in each status for each Account with two Products on each sales order.</p>\r\n<p>Enter a quantity of 10 for one product and 5 for the other.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Expected result</strong></p>\r\n<p>Login to the portal as Contact 1</p>\r\n<p>Select status: Alla -&gt; The Sales Orders for Account 1 are showed&nbsp;</p>\r\n<p>Select status: Skapad -&gt; The Sales Orders in status Created for Account 1 are showed</p>\r\n<p>Select status: Godk&auml;nd -&gt; The Sales Orders in status Approved&nbsp;for Account 1 are showed</p>\r\n<p>Select status: Levererad -&gt; The Sales Orders in status Delivered&nbsp;for Account 1 are showed</p>\r\n<p>Select status: Avbruten -&gt; The Sales Orders in status CAncelled&nbsp;for Account 1 are showed</p>\r\n<p>Select status: St&auml;ngd -&gt; The Sales Orders in status Closed&nbsp;for Account 1 are showed</p>\r\n<p>&nbsp;</p>\r\n<p>Login as Contact 2&nbsp;</p>\r\n<p>Select status: Skapad -&gt; The Sales Orders in status Created for Account 2 are showed</p>\r\n<p>Select status: Godk&auml;nd -&gt; The Sales Orders in status Approved&nbsp;for Account 2 are showed</p>\r\n<p>Select status: Levererad -&gt; The Sales Orders in status Delivered&nbsp;for Account 2 are showed</p>\r\n<p>Select status: Avbruten -&gt; The Sales Orders in status CAncelled&nbsp;for Account 2 are showed</p>\r\n<p>Select status: St&auml;ngd -&gt; The Sales Orders in status Closed&nbsp;for Account 2 are showed</p>\r\n<p>&nbsp;</p>\r\n<p>Login as Contact 3</p>\r\n<p>Select status: Skapad -&gt; The Sales Orders in status Created for Account 1 and Account 2&nbsp;are showed</p>\r\n<p>Select status: Godk&auml;nd -&gt; The Sales Orders in status Approved&nbsp;for Account 1 and Account 2 are showed</p>\r\n<p>Select status: Levererad -&gt; The Sales Orders in status Delivered&nbsp;for Account 1 and Account 2 are showed</p>\r\n<p>Select status: Avbruten -&gt; The Sales Orders in status CAncelled&nbsp;for Account 1 and Account 2 are showed</p>\r\n<p>Select status: St&auml;ngd -&gt; The Sales Orders in status Closed&nbsp;for Account 1 and Account 2 are showed<b><br />\r\n</b></p>','<p>&nbsp;Accounts, Products, Account/Product and Contacts</p>',2,2,'2012-03-21 09:22:02',2,'2012-03-21 09:25:33',1,1,1),(48,5,2,1,1,'<p><strong>Test data - </strong><span style=\"color: rgb(255, 102, 0); \">SPECIFY THE&nbsp;DATA TO BE USED</span></p>\r\n<p>Account 1: test</p>\r\n<p>Product 1: Cykel Velobris 21&quot;</p>\r\n<p>Product 2: Brother Ink Jet Cartridge</p>\r\n<p>&nbsp;</p>\r\n<p>Account 2: test 2</p>\r\n<p>Product : Vtiger 50 Users Pack</p>\r\n<br />\r\n<p>Make sure that Account 1 and Account 2 both have Product 1 and Product 2 listed under More information-&gt;Products.</p>\r\n<p>Contact 1 (for Account 1): ashish-purwar@essindia.co.in//123456</p>\r\n<p>Contact 2 (for Account 2): gaurav-rana@essindia.co.in//123456</p>\r\n<p>Contact 3 (Central portal user):</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Test</strong></p>\r\n<p>In vTiger:&nbsp;Create Sales Orders for the wo Accounts (stores) above. Create one sales order in each status for each Account with two Products on each sales order.</p>\r\n<p>Enter a quantity of 10 for one product and 5 for the other.</p>\r\n<p>&nbsp;</p>\r\n<p><strong>Expected result</strong></p>\r\n<p>Login to the portal as Contact 1</p>\r\n<p>Select status: Alla -&gt; The Sales Orders for Account 1 are showed&nbsp;</p>\r\n<p>Select status: Skapad -&gt; The Sales Orders in status Created for Account 1 are showed</p>\r\n<p>Select status: Godk&auml;nd -&gt; The Sales Orders in status Approved&nbsp;for Account 1 are showed</p>\r\n<p>Select status: Levererad -&gt; The Sales Orders in status Delivered&nbsp;for Account 1 are showed</p>\r\n<p>Select status: Avbruten -&gt; The Sales Orders in status CAncelled&nbsp;for Account 1 are showed</p>\r\n<p>Select status: St&auml;ngd -&gt; The Sales Orders in status Closed&nbsp;for Account 1 are showed</p>\r\n<p>&nbsp;</p>\r\n<p>Login as Contact 2&nbsp;</p>\r\n<p>Select status: Skapad -&gt; The Sales Orders in status Created for Account 2 are showed</p>\r\n<p>Select status: Godk&auml;nd -&gt; The Sales Orders in status Approved&nbsp;for Account 2 are showed</p>\r\n<p>Select status: Levererad -&gt; The Sales Orders in status Delivered&nbsp;for Account 2 are showed</p>\r\n<p>Select status: Avbruten -&gt; The Sales Orders in status CAncelled&nbsp;for Account 2 are showed</p>\r\n<p>Select status: St&auml;ngd -&gt; The Sales Orders in status Closed&nbsp;for Account 2 are showed</p>\r\n<p>&nbsp;</p>\r\n<p>Login as Contact 3</p>\r\n<p>Select status: Skapad -&gt; The Sales Orders in status Created for Account 1 and Account 2&nbsp;are showed</p>\r\n<p>Select status: Godk&auml;nd -&gt; The Sales Orders in status Approved&nbsp;for Account 1 and Account 2 are showed</p>\r\n<p>Select status: Levererad -&gt; The Sales Orders in status Delivered&nbsp;for Account 1 and Account 2 are showed</p>\r\n<p>Select status: Avbruten -&gt; The Sales Orders in status CAncelled&nbsp;for Account 1 and Account 2 are showed</p>\r\n<p>Select status: St&auml;ngd -&gt; The Sales Orders in status Closed&nbsp;for Account 1 and Account 2 are showed<b><br />\r\n</b></p>','<p>&nbsp;Accounts, Products, Account/Product and Contacts</p>',2,2,'2012-03-23 08:19:35',4,'2012-04-06 11:06:14',1,1,1),(95,6,1,1,1,'<p>&nbsp;Use Key business test conditions from sytem documentation:</p>\r\n<p>https://gom-docs.gizurcloud.com/doku.php?id=system_docs:integration:vtiger_sales_orders_export</p>','',2,2,'2012-05-11 11:36:20',4,'2012-05-22 14:40:13',1,1,1),(97,7,1,1,1,'<p>&nbsp;Use Key business test conditions from sytsem documentation:</p>\r\n<p>https://gom-docs.gizurcloud.com/doku.php?id=system_docs:integration:vtiger_sales_orders_export</p>','',2,2,'2012-05-11 11:37:01',4,'2012-06-06 08:36:02',1,1,1),(99,8,1,1,1,'<p style=\"margin-top: 0px; font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">&nbsp;Use Key business test conditions from sytsem documentation:</p>\r\n<p style=\"font-family: \'Trebuchet MS\', Arial, Verdana, sans-serif; text-align: left; background-color: rgb(238, 238, 238); \">https://gom-docs.gizurcloud.com/doku.php?id=system_docs:integration:vtiger_sales_orders_export</p>','',2,2,'2012-05-11 11:38:12',4,'2012-06-07 07:56:01',1,1,1),(145,6,2,1,1,'<p>&nbsp;Use Key business test conditions from sytem documentation:</p>\r\n<p>https://gom-docs.gizurcloud.com/doku.php?id=system_docs:integration:vtiger_sales_orders_export</p>','',2,4,'2012-06-06 07:17:24',4,'2012-06-06 08:14:54',1,1,1),(222,3,1,1,1,'','',2,4,'2012-09-05 13:11:21',4,'2012-09-06 15:28:28',1,1,1),(192,2,1,1,1,'','',2,4,'2012-09-05 11:06:10',4,'2012-09-06 11:38:49',1,1,1),(233,4,1,1,1,'','',2,4,'2012-09-06 12:10:10',4,'2012-09-06 14:56:06',1,1,1),(271,5,1,1,1,'','',2,4,'2012-09-06 15:29:57',4,'2012-09-06 15:48:14',1,1,1),(292,6,1,1,1,'','',2,4,'2012-09-07 07:16:13',4,'2012-09-07 07:30:17',1,1,1),(312,7,1,1,1,'','',2,4,'2012-09-07 07:34:27',4,'2012-09-07 08:07:16',1,1,1),(361,1,1,1,1,'<p>Here app is tested for bringing public-private key into app.</p>','',2,6,'2012-09-17 10:26:57',6,'2012-09-17 12:04:13',1,1,1),(364,2,1,1,1,'','',2,6,'2012-09-17 10:34:21',6,'2012-09-17 10:36:48',1,1,1),(369,3,1,1,1,'','',2,6,'2012-09-17 10:37:28',6,'2012-09-17 10:38:47',1,1,1),(374,4,1,1,1,'','',2,6,'2012-09-17 10:39:34',6,'2012-09-17 10:42:06',1,1,1),(379,5,1,1,1,'','',2,6,'2012-09-17 10:42:13',6,'2012-09-17 10:43:22',1,1,1),(384,6,1,1,1,'','',2,6,'2012-09-17 10:44:17',6,'2012-09-17 10:46:50',1,1,1),(389,7,1,1,1,'','',2,6,'2012-09-17 12:01:23',6,'2012-09-17 12:03:21',1,1,1),(392,8,1,1,1,'','',2,6,'2012-09-17 12:05:15',6,'2012-09-17 12:08:41',1,1,1),(395,9,1,1,1,'','',2,6,'2012-09-17 14:25:06',6,'2012-09-17 14:26:21',1,1,1),(398,10,1,1,1,'','',2,6,'2012-09-17 14:31:34',6,'2012-09-17 14:33:42',1,1,1),(403,11,1,1,1,'','',2,6,'2012-09-17 14:34:51',6,'2012-09-17 14:41:30',1,1,1),(406,12,1,1,1,'<p>If the user try to report damage again then earlier damage should be updated if there is new data in it. like new image. It should not create trouble ticket for duplicate report.</p>','',2,6,'2012-09-17 14:44:33',6,'2012-09-17 15:13:52',1,1,1),(410,13,1,1,1,'<p>Here it is checked that the position list is appearing as per the selected type </p>','',2,6,'2012-09-17 14:53:16',6,'2012-09-17 14:57:59',1,1,1),(416,14,1,1,1,'','',2,6,'2012-09-18 06:57:14',6,'2012-09-18 07:01:29',1,1,1),(419,15,1,1,1,'','',2,6,'2012-09-18 07:02:55',6,'2012-09-18 07:04:44',1,1,1),(422,16,1,1,1,'','<p>All needed survey fields should be filled</p>',2,6,'2012-09-18 07:12:30',6,'2012-10-01 09:46:45',1,1,1),(424,17,1,1,1,'','',2,6,'2012-09-18 07:34:14',6,'2012-09-18 07:36:24',1,1,1),(427,18,1,1,1,'','',2,6,'2012-09-18 08:14:28',6,'2012-09-18 08:17:14',1,1,1),(430,19,1,1,1,'','',2,6,'2012-09-18 08:18:30',6,'2012-09-18 08:25:54',1,1,1),(434,20,1,1,1,'','',2,6,'2012-09-18 12:02:04',6,'2012-09-19 08:01:44',1,1,1),(480,26,1,1,1,'','',2,6,'2012-09-19 08:29:06',6,'2012-09-19 08:51:42',1,1,1),(440,23,1,1,1,'','',2,6,'2012-09-18 12:05:14',6,'2012-09-19 08:48:10',1,1,1),(490,27,1,1,1,'','',2,6,'2012-09-19 08:53:21',6,'2012-10-01 09:50:51',1,1,1),(457,25,1,1,1,'','',2,6,'2012-09-19 07:48:42',6,'2012-09-19 08:02:07',1,1,1),(500,28,1,1,1,'','',2,6,'2012-10-01 10:26:07',6,'2012-10-01 10:27:59',1,1,1),(541,9,1,1,1,'<p>Test data:</p>\r\n<p>Organisation: TEST</p>\r\n<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Contact: Jonas Colmsjo</p>\r\n\r\n<p>Test:</p>\r\n<p>Create new Quote with the above mentioned product and set the quantity to 10.</p>','<p>Product, Organisation and Contact must be added before executing this.</p>',2,7,'2012-12-13 09:36:50',7,'2012-12-13 09:55:30',1,1,1),(544,10,1,1,1,'<p>Test data:</p>\r\n<p>Organisation: TEST</p>\r\n<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Contact: Jonas Colmsjo</p>\r\n\r\n<p>Test:</p>\r\n<p>Create new SalesOrder with the above mentioned product and set the quantity to 10.</p>','<p>Product, Organisation, and Contact must be added before executing this.</p>\r\n<p>A quotation must already been added before executing this case.</p>',2,7,'2012-12-13 09:43:11',7,'2012-12-13 10:24:22',1,1,1),(557,11,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Call-Off the product by 10.</p>\r\n\r\n<p><b>Result</b></p>\r\n<p>A new sales order will be created with the entered quantity and sale order column value will be increased by the same for the selected product.</p>','<p>In the bikeportal, make sure that the left order value is greater than 0 in the CikabTroubleTicket module.</p>',2,7,'2012-12-13 11:28:01',7,'2012-12-13 11:39:32',1,1,1),(564,12,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Increase the product quantity by 10.</p>\r\n<p>Result</p>\r\n<p>A new ticket will be generated for the selected product.</p>','In the bikeportal, make sure at least one product is listed in the CikabTroubleTicket module.',2,7,'2012-12-13 12:03:04',7,'2012-12-13 12:13:59',1,1,1),(570,13,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Decrease the product quantity by 10.</p>\r\n<p>Result</p>\r\n<p>A new ticket will be generated for the selected product.</p>','In the bikeportal, make sure at least one product is listed in the CikabTroubleTicket module.',2,7,'2012-12-13 12:21:25',7,'2012-12-13 12:32:56',1,1,1),(576,14,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Decrease the product quantity by 30.</p>\r\n<p>Result</p>\r\n<p>A new ticket will be generated for the selected product.</p>\r\n<p>Previous increase request ticket(s) with the same quantity will be closed, if any and a new ticket will be created with the balance quantity.</p>','<p>In the bikeportal, make sure at least one product is listed in the CikabTroubleTicket module.</p>',2,7,'2012-12-14 06:13:05',7,'2012-12-14 06:17:00',1,1,1),(582,15,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Increase product quantity by 50</p>\r\n<p>Result</p>\r\n<p>A new ticket will be generated for the selected product.</p>\r\n<p>Previous decrease request ticket(s) with the same or less quantity will be closed and a new ticket will be created with the balance quantity.</p>','<p>In the bikeportal, make sure at least one product is listed in the CikabTroubleTicket module.</p>',2,7,'2012-12-14 06:21:54',7,'2012-12-14 06:30:13',1,1,1),(588,16,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Increase product quantity by 30</p>\r\n<p>Result</p>\r\n<p>A new ticket will be generated for the selected product.</p>\r\n<p>Previous decrease request ticket(s) with the same or less quantity will be closed and a new ticket will be created with the balance quantity.</p>','<p>In the bikeportal, make sure at least one product is listed in the CikabTroubleTicket module.</p>',2,7,'2012-12-14 06:44:05',7,'2012-12-14 07:14:27',1,1,1),(594,17,1,1,1,'<p>Product: 202035 (SPARKCYKEL ROSA)</p>\r\n<p>Decrease the product quantity by 30.</p>\r\n<p>Result</p>\r\n<p>A new ticket will be generated for the selected product.</p>\r\n<p>Previous increase request ticket(s) with the same quantity will be closed and a new ticket will be created with the balance quantity.</p>','<p>In the bikeportal, make sure at least one product is listed in the CikabTroubleTicket module.</p>',2,7,'2012-12-14 06:45:51',7,'2012-12-14 06:47:49',1,1,1),(600,18,1,1,1,'','',2,7,'2012-12-19 06:18:51',7,'2012-12-20 11:17:20',1,1,1);
/*!40000 ALTER TABLE `tcversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testcase_keywords`
--

DROP TABLE IF EXISTS `testcase_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testcase_keywords` (
  `testcase_id` int(10) unsigned NOT NULL DEFAULT '0',
  `keyword_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`testcase_id`,`keyword_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testcase_keywords`
--

LOCK TABLES `testcase_keywords` WRITE;
/*!40000 ALTER TABLE `testcase_keywords` DISABLE KEYS */;
/*!40000 ALTER TABLE `testcase_keywords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplan_platforms`
--

DROP TABLE IF EXISTS `testplan_platforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testplan_platforms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL,
  `platform_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_testplan_platforms` (`testplan_id`,`platform_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Connects a testplan with platforms';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplan_platforms`
--

LOCK TABLES `testplan_platforms` WRITE;
/*!40000 ALTER TABLE `testplan_platforms` DISABLE KEYS */;
INSERT INTO `testplan_platforms` VALUES (1,498,1),(3,502,2);
/*!40000 ALTER TABLE `testplan_platforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplan_tcversions`
--

DROP TABLE IF EXISTS `testplan_tcversions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testplan_tcversions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `testplan_id` int(10) unsigned NOT NULL DEFAULT '0',
  `tcversion_id` int(10) unsigned NOT NULL DEFAULT '0',
  `node_order` int(10) unsigned NOT NULL DEFAULT '1',
  `urgency` smallint(5) NOT NULL DEFAULT '2',
  `platform_id` int(10) unsigned NOT NULL DEFAULT '0',
  `author_id` int(10) unsigned DEFAULT NULL,
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `testplan_tcversions_tplan_tcversion` (`testplan_id`,`tcversion_id`,`platform_id`)
) ENGINE=MyISAM AUTO_INCREMENT=119 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplan_tcversions`
--

LOCK TABLES `testplan_tcversions` WRITE;
/*!40000 ALTER TABLE `testplan_tcversions` DISABLE KEYS */;
INSERT INTO `testplan_tcversions` VALUES (1,10,13,1,2,0,1,'2012-03-12 15:36:56'),(5,100,95,1,2,0,2,'2012-05-23 09:13:43'),(4,40,47,1,2,0,4,'2012-03-23 07:42:55'),(6,40,95,1,2,0,4,'2012-05-23 10:14:16'),(7,100,97,1,2,0,4,'2012-05-30 07:32:25'),(8,100,99,1,2,0,4,'2012-06-11 12:35:36'),(9,498,392,10,2,1,6,'2012-10-01 10:02:19'),(10,498,395,20,2,1,6,'2012-10-01 10:02:19'),(11,498,389,70,2,1,6,'2012-10-01 10:02:19'),(12,498,416,80,2,1,6,'2012-10-01 10:02:19'),(13,498,419,90,2,1,6,'2012-10-01 10:02:19'),(14,498,422,100,2,1,6,'2012-10-01 10:02:19'),(15,498,361,0,2,1,6,'2012-10-01 10:02:26'),(16,498,364,10,2,1,6,'2012-10-01 10:02:26'),(17,498,369,20,2,1,6,'2012-10-01 10:02:26'),(18,498,374,30,2,1,6,'2012-10-01 10:02:26'),(19,498,379,40,2,1,6,'2012-10-01 10:02:26'),(20,498,384,50,2,1,6,'2012-10-01 10:02:26'),(21,498,398,0,2,1,6,'2012-10-01 10:02:41'),(22,498,403,40,2,1,6,'2012-10-01 10:02:41'),(23,498,406,50,2,1,6,'2012-10-01 10:02:41'),(24,498,410,60,2,1,6,'2012-10-01 10:02:41'),(25,498,424,70,2,1,6,'2012-10-01 10:02:41'),(26,498,430,80,2,1,6,'2012-10-01 10:02:41'),(27,498,427,100,2,1,6,'2012-10-01 10:02:59'),(28,498,490,0,2,1,6,'2012-10-01 10:28:49'),(29,498,480,10,2,1,6,'2012-10-01 10:28:49'),(30,498,457,20,2,1,6,'2012-10-01 10:28:49'),(31,498,434,30,2,1,6,'2012-10-01 10:28:49'),(32,498,440,40,2,1,6,'2012-10-01 10:28:49'),(33,498,500,50,2,1,6,'2012-10-01 10:28:49'),(108,502,500,50,2,2,6,'2012-10-03 10:26:28'),(107,502,440,40,2,2,6,'2012-10-03 10:26:28'),(106,502,434,30,2,2,6,'2012-10-03 10:26:28'),(105,502,457,20,2,2,6,'2012-10-03 10:26:28'),(104,502,480,10,2,2,6,'2012-10-03 10:26:28'),(103,502,490,0,2,2,6,'2012-10-03 10:26:28'),(102,502,430,80,2,2,6,'2012-10-03 10:26:28'),(101,502,424,70,2,2,6,'2012-10-03 10:26:28'),(100,502,410,60,2,2,6,'2012-10-03 10:26:28'),(99,502,406,50,2,2,6,'2012-10-03 10:26:28'),(98,502,403,40,2,2,6,'2012-10-03 10:26:28'),(97,502,398,0,2,2,6,'2012-10-03 10:26:28'),(96,502,422,100,2,2,6,'2012-10-03 10:26:28'),(95,502,419,90,2,2,6,'2012-10-03 10:26:28'),(94,502,416,80,2,2,6,'2012-10-03 10:26:28'),(93,502,389,70,2,2,6,'2012-10-03 10:26:28'),(92,502,395,20,2,2,6,'2012-10-03 10:26:28'),(91,502,392,10,2,2,6,'2012-10-03 10:26:28'),(90,502,384,50,2,2,6,'2012-10-03 10:26:28'),(89,502,379,40,2,2,6,'2012-10-03 10:26:28'),(88,502,374,30,2,2,6,'2012-10-03 10:26:28'),(87,502,369,20,2,2,6,'2012-10-03 10:26:28'),(86,502,364,10,2,2,6,'2012-10-03 10:26:28'),(85,502,361,0,2,2,6,'2012-10-03 10:26:28'),(84,502,427,100,2,2,6,'2012-10-03 10:26:28'),(109,539,541,1,2,0,7,'2012-12-13 09:39:57'),(110,539,544,1,2,0,7,'2012-12-13 10:25:08'),(111,539,557,1,2,0,7,'2012-12-13 11:40:48'),(112,539,564,1,2,0,7,'2012-12-13 12:14:54'),(113,539,570,1,2,0,7,'2012-12-13 12:26:44'),(114,539,576,1,2,0,7,'2012-12-14 06:17:23'),(115,539,582,1,2,0,7,'2012-12-14 06:30:54'),(116,539,594,1,2,0,7,'2012-12-14 07:02:23'),(117,539,588,1,2,0,7,'2012-12-14 07:15:02'),(118,539,600,1,2,0,7,'2012-12-20 11:50:18');
/*!40000 ALTER TABLE `testplan_tcversions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testplans`
--

DROP TABLE IF EXISTS `testplans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testplans` (
  `id` int(10) unsigned NOT NULL,
  `testproject_id` int(10) unsigned NOT NULL DEFAULT '0',
  `notes` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `is_open` tinyint(1) NOT NULL DEFAULT '1',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `testplans_testproject_id_active` (`testproject_id`,`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testplans`
--

LOCK TABLES `testplans` WRITE;
/*!40000 ALTER TABLE `testplans` DISABLE KEYS */;
INSERT INTO `testplans` VALUES (7,1,'<p>&nbsp;This is the first test plan</p>',1,1,1),(10,8,'<p>&nbsp;Ensure that sales order and quotes are diplayed correctly.</p>\r\n<p>Also ensure that Trouble Tickets are created.</p>',1,1,1),(40,8,'',1,1,1),(45,8,'<p>asd</p>',1,1,1),(100,8,'',1,1,1),(185,8,'',1,1,1),(498,355,'',1,1,1),(502,355,'',1,1,1),(539,8,'This plan contains all test cases to test the new functionality added in the vTiger version 5.4.0 and bikeportal version 5.4.0.',1,1,1);
/*!40000 ALTER TABLE `testplans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testprojects`
--

DROP TABLE IF EXISTS `testprojects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testprojects` (
  `id` int(10) unsigned NOT NULL,
  `notes` text,
  `color` varchar(12) NOT NULL DEFAULT '#9BD',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `option_reqs` tinyint(1) NOT NULL DEFAULT '0',
  `option_priority` tinyint(1) NOT NULL DEFAULT '0',
  `option_automation` tinyint(1) NOT NULL DEFAULT '0',
  `options` text,
  `prefix` varchar(16) NOT NULL,
  `tc_counter` int(10) unsigned NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `testprojects_prefix` (`prefix`),
  KEY `testprojects_id_active` (`id`,`active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testprojects`
--

LOCK TABLES `testprojects` WRITE;
/*!40000 ALTER TABLE `testprojects` DISABLE KEYS */;
INSERT INTO `testprojects` VALUES (1,'','',1,0,0,0,'O:8:\"stdClass\":4:{s:19:\"requirementsEnabled\";i:0;s:19:\"testPriorityEnabled\";i:0;s:17:\"automationEnabled\";i:0;s:16:\"inventoryEnabled\";i:0;}','TEST',2,1),(8,'<p>&nbsp;vTiger implementation for management of quotes and sales orders</p>','',1,0,0,0,'O:8:\"stdClass\":4:{s:19:\"requirementsEnabled\";i:0;s:19:\"testPriorityEnabled\";i:0;s:17:\"automationEnabled\";i:0;s:16:\"inventoryEnabled\";i:0;}','CIKABNFS',18,1),(186,'','',1,0,0,0,'O:8:\"stdClass\":4:{s:19:\"requirementsEnabled\";i:0;s:19:\"testPriorityEnabled\";i:0;s:17:\"automationEnabled\";i:0;s:16:\"inventoryEnabled\";i:0;}','CLABTP',7,1),(355,'','',1,0,0,0,'O:8:\"stdClass\":4:{s:19:\"requirementsEnabled\";i:0;s:19:\"testPriorityEnabled\";i:0;s:17:\"automationEnabled\";i:0;s:16:\"inventoryEnabled\";i:0;}','GSLABS',28,1);
/*!40000 ALTER TABLE `testprojects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testsuites`
--

DROP TABLE IF EXISTS `testsuites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testsuites` (
  `id` int(10) unsigned NOT NULL,
  `details` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testsuites`
--

LOCK TABLES `testsuites` WRITE;
/*!40000 ALTER TABLE `testsuites` DISABLE KEYS */;
INSERT INTO `testsuites` VALUES (2,'<p>&nbsp;First test suite</p>'),(11,'<p>&nbsp;Contains test cases for the cusotm built Cikab Trouble Ticket screen in the portal</p>'),(22,'<p>&nbsp;Contains test cases for the custom built Sales Order Screen in the portal</p>'),(23,'<p>&nbsp;Contains test cases for the custom built Vendor portal</p>'),(93,'<p>&nbsp;The system documentation can be found here:</p>\r\n<p>https://gom-docs.gizurcloud.com/doku.php?id=system_docs:integration:vtiger_sales_orders_export</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>'),(187,''),(188,''),(224,''),(225,''),(359,''),(227,''),(358,''),(231,''),(413,''),(414,''),(432,''),(542,'');
/*!40000 ALTER TABLE `testsuites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_point` varchar(45) NOT NULL DEFAULT '',
  `start_time` int(10) unsigned NOT NULL DEFAULT '0',
  `end_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `session_id` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=534 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (478,'/lib/testcases/tcEdit.php',1355397294,1355397294,7,'9p37fdgkk5thirk5636nifl097'),(479,'/lib/execute/execSetResults.php',1355397388,1355397388,7,'9p37fdgkk5thirk5636nifl097'),(480,'/lib/attachments/attachmentupload.php',1355397416,1355397416,7,'9p37fdgkk5thirk5636nifl097'),(481,'/lib/attachments/attachmentupload.php',1355397498,1355397498,7,'9p37fdgkk5thirk5636nifl097'),(482,'/lib/attachments/attachmentupload.php',1355397517,1355397517,7,'9p37fdgkk5thirk5636nifl097'),(483,'/lib/attachments/attachmentdelete.php',1355397558,1355397558,7,'9p37fdgkk5thirk5636nifl097'),(484,'/lib/attachments/attachmentdelete.php',1355397567,1355397567,7,'9p37fdgkk5thirk5636nifl097'),(485,'/lib/attachments/attachmentupload.php',1355397596,1355397596,7,'9p37fdgkk5thirk5636nifl097'),(486,'/lib/attachments/attachmentupload.php',1355397616,1355397616,7,'9p37fdgkk5thirk5636nifl097'),(487,'/lib/testcases/tcEdit.php',1355398004,1355398004,7,'9p37fdgkk5thirk5636nifl097'),(488,'/lib/execute/execSetResults.php',1355398398,1355398398,7,'9p37fdgkk5thirk5636nifl097'),(489,'/lib/attachments/attachmentupload.php',1355398447,1355398447,7,'9p37fdgkk5thirk5636nifl097'),(490,'/lib/attachments/attachmentupload.php',1355398468,1355398468,7,'9p37fdgkk5thirk5636nifl097'),(491,'/lib/attachments/attachmentdelete.php',1355398514,1355398514,7,'9p37fdgkk5thirk5636nifl097'),(492,'/lib/attachments/attachmentupload.php',1355398540,1355398540,7,'9p37fdgkk5thirk5636nifl097'),(493,'/lib/attachments/attachmentupload.php',1355398564,1355398564,7,'9p37fdgkk5thirk5636nifl097'),(494,'/login.php',1355461945,1355461945,7,'9p37fdgkk5thirk5636nifl097'),(495,'/lib/testcases/tcEdit.php',1355462243,1355462244,7,'9p37fdgkk5thirk5636nifl097'),(496,'/lib/execute/execSetResults.php',1355462307,1355462307,7,'9p37fdgkk5thirk5636nifl097'),(497,'/lib/attachments/attachmentupload.php',1355462340,1355462340,7,'9p37fdgkk5thirk5636nifl097'),(498,'/lib/attachments/attachmentupload.php',1355462360,1355462360,7,'9p37fdgkk5thirk5636nifl097'),(499,'/lib/testcases/tcEdit.php',1355463054,1355463054,7,'9p37fdgkk5thirk5636nifl097'),(500,'/lib/execute/execSetResults.php',1355463128,1355463128,7,'9p37fdgkk5thirk5636nifl097'),(501,'/lib/attachments/attachmentupload.php',1355463154,1355463154,7,'9p37fdgkk5thirk5636nifl097'),(502,'/lib/attachments/attachmentupload.php',1355463173,1355463173,7,'9p37fdgkk5thirk5636nifl097'),(503,'/lib/testcases/tcEdit.php',1355464943,1355464943,7,'9p37fdgkk5thirk5636nifl097'),(504,'/lib/execute/execSetResults.php',1355464965,1355464965,7,'9p37fdgkk5thirk5636nifl097'),(505,'/lib/attachments/attachmentupload.php',1355464991,1355464991,7,'9p37fdgkk5thirk5636nifl097'),(506,'/lib/attachments/attachmentupload.php',1355465006,1355465006,7,'9p37fdgkk5thirk5636nifl097'),(507,'/lib/testcases/tcEdit.php',1355465702,1355465702,7,'9p37fdgkk5thirk5636nifl097'),(508,'/lib/execute/execSetResults.php',1355465725,1355465725,7,'9p37fdgkk5thirk5636nifl097'),(509,'/lib/attachments/attachmentupload.php',1355465833,1355465833,7,'9p37fdgkk5thirk5636nifl097'),(510,'/lib/attachments/attachmentupload.php',1355465849,1355465850,7,'9p37fdgkk5thirk5636nifl097'),(511,'/login.php',1355471182,1355471182,2,'vhvq0sa4nng61bsr558dgrj536'),(512,'/lib/attachments/attachmentdownload.php',1355471393,1355471393,2,'vhvq0sa4nng61bsr558dgrj536'),(513,'/lib/attachments/attachmentdownload.php',1355471405,1355471405,2,'vhvq0sa4nng61bsr558dgrj536'),(514,'/lib/attachments/attachmentdownload.php',1355471411,1355471411,2,'vhvq0sa4nng61bsr558dgrj536'),(515,'/lib/attachments/attachmentdownload.php',1355471449,1355471449,2,'vhvq0sa4nng61bsr558dgrj536'),(516,'/login.php',1355472772,1355472772,7,'9p37fdgkk5thirk5636nifl097'),(517,'/login.php',1355474849,1355474849,0,NULL),(518,'/login.php',1355474858,1355474858,2,'gh8gm3mu9fj1h4j8g0n9qd13u3'),(519,'/lib/attachments/attachmentdownload.php',1355474889,1355474889,2,'gh8gm3mu9fj1h4j8g0n9qd13u3'),(520,'/login.php',1355475020,1355475020,7,'7ncr4ug0u0bncamg4atp0ihfr0'),(521,'/login.php',1355475491,1355475491,2,'vhvq0sa4nng61bsr558dgrj536'),(522,'/login.php',1355479402,1355479402,7,'7ncr4ug0u0bncamg4atp0ihfr0'),(523,'/login.php',1355897097,1355897097,7,'3n7jna8r934uql7ec6e17hk8h3'),(525,'/logout.php',1355939801,1355939801,7,'3n7jna8r934uql7ec6e17hk8h3'),(526,'/login.php',1355984509,1355984509,7,'3n7jna8r934uql7ec6e17hk8h3'),(529,'/lib/testcases/tcEdit.php',1356004218,1356004218,7,'i4jj7d8bs70fgcqlhnjr10ecc5'),(530,'/lib/execute/execSetResults.php',1356004241,1356004241,7,'i4jj7d8bs70fgcqlhnjr10ecc5'),(531,'/logout.php',1356004251,1356004251,7,'i4jj7d8bs70fgcqlhnjr10ecc5'),(532,'/login.php',1356075944,1356075944,7,'i4jj7d8bs70fgcqlhnjr10ecc5'),(533,'/login.php',1356081014,1356081014,2,'nfe4v6k3ssb98ga0pjbhmf77t4'),(475,'/lib/attachments/attachmentupload.php',1355395688,1355395688,7,'9p37fdgkk5thirk5636nifl097'),(476,'/lib/attachments/attachmentupload.php',1355395728,1355395728,7,'9p37fdgkk5thirk5636nifl097'),(477,'/lib/attachments/attachmentupload.php',1355396002,1355396002,7,'9p37fdgkk5thirk5636nifl097'),(474,'/lib/execute/execSetResults.php',1355395442,1355395442,7,'9p37fdgkk5thirk5636nifl097'),(473,'/lib/testcases/tcEdit.php',1355395248,1355395248,7,'9p37fdgkk5thirk5636nifl097'),(472,'/lib/execute/execSetResults.php',1355390915,1355390915,7,'9p37fdgkk5thirk5636nifl097'),(471,'/lib/execute/execSetResults.php',1355390900,1355390900,7,'9p37fdgkk5thirk5636nifl097'),(470,'/lib/plan/buildEdit.php',1355390839,1355390839,7,'9p37fdgkk5thirk5636nifl097'),(469,'/lib/testcases/tcEdit.php',1355390708,1355390708,7,'9p37fdgkk5thirk5636nifl097'),(468,'/lib/testcases/tcEdit.php',1355388092,1355388092,7,'9p37fdgkk5thirk5636nifl097'),(467,'/lib/testcases/tcEdit.php',1355387997,1355387997,7,'9p37fdgkk5thirk5636nifl097'),(466,'/lib/plan/planEdit.php',1355386744,1355386744,7,'9p37fdgkk5thirk5636nifl097'),(462,'/lib/testcases/tcPrint.php',1355382570,1355382570,7,'9p37fdgkk5thirk5636nifl097'),(463,'/lib/testcases/tcPrint.php',1355382589,1355382589,7,'9p37fdgkk5thirk5636nifl097'),(464,'/login.php',1355386409,1355386409,7,'9p37fdgkk5thirk5636nifl097'),(465,'/lib/testcases/tcEdit.php',1355386542,1355386542,7,'9p37fdgkk5thirk5636nifl097'),(461,'/lib/testcases/tcPrint.php',1355382518,1355382518,7,'9p37fdgkk5thirk5636nifl097'),(524,'/login.php',1355938421,1355938421,7,'3n7jna8r934uql7ec6e17hk8h3'),(528,'/login.php',1356004178,1356004178,7,'i4jj7d8bs70fgcqlhnjr10ecc5'),(527,'/login.php',1355998566,1355998566,7,'i4jj7d8bs70fgcqlhnjr10ecc5'),(450,'/login.php',1355221675,1355221675,7,'qnn3j7aoll28btme9dm4u9dkr0'),(451,'/lib/usermanagement/usersAssign.php',1355221993,1355221993,7,'qnn3j7aoll28btme9dm4u9dkr0'),(452,'/lib/usermanagement/usersAssign.php',1355221999,1355221999,7,'qnn3j7aoll28btme9dm4u9dkr0'),(453,'/logout.php',1355223160,1355223160,7,'qnn3j7aoll28btme9dm4u9dkr0'),(454,'/login.php',1355224280,1355224280,7,'qnn3j7aoll28btme9dm4u9dkr0'),(455,'/login.php',1355286070,1355286070,7,'m15mci45iikcr3lsdnnn4bha80'),(456,'/login.php',1355310634,1355310634,4,'c5hpm5dd136fuv9lagb35o8ph0'),(457,'/logout.php',1355311441,1355311441,4,'c5hpm5dd136fuv9lagb35o8ph0'),(458,'/login.php',1355374783,1355374783,7,'9p37fdgkk5thirk5636nifl097'),(459,'/lib/testcases/tcEdit.php',1355378996,1355378996,7,'9p37fdgkk5thirk5636nifl097'),(460,'/lib/testcases/tcPrint.php',1355381503,1355381503,7,'9p37fdgkk5thirk5636nifl097'),(449,'/lib/testcases/archiveData.php',1354869764,1354869764,2,'j9lj7p65mn1pnbng7it3t85765'),(448,'/login.php',1354869734,1354869734,2,'j9lj7p65mn1pnbng7it3t85765');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_assignments`
--

DROP TABLE IF EXISTS `user_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_assignments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) unsigned NOT NULL DEFAULT '1',
  `feature_id` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned DEFAULT '0',
  `build_id` int(10) unsigned DEFAULT '0',
  `deadline_ts` datetime DEFAULT NULL,
  `assigner_id` int(10) unsigned DEFAULT '0',
  `creation_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(10) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `user_assignments_feature_id` (`feature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_assignments`
--

LOCK TABLES `user_assignments` WRITE;
/*!40000 ALTER TABLE `user_assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_assignments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_user_group` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_assign`
--

DROP TABLE IF EXISTS `user_group_assign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group_assign` (
  `usergroup_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `idx_user_group_assign` (`usergroup_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_assign`
--

LOCK TABLES `user_group_assign` WRITE;
/*!40000 ALTER TABLE `user_group_assign` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_group_assign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_testplan_roles`
--

DROP TABLE IF EXISTS `user_testplan_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_testplan_roles` (
  `user_id` int(10) NOT NULL DEFAULT '0',
  `testplan_id` int(10) NOT NULL DEFAULT '0',
  `role_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`testplan_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_testplan_roles`
--

LOCK TABLES `user_testplan_roles` WRITE;
/*!40000 ALTER TABLE `user_testplan_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_testplan_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_testproject_roles`
--

DROP TABLE IF EXISTS `user_testproject_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_testproject_roles` (
  `user_id` int(10) NOT NULL DEFAULT '0',
  `testproject_id` int(10) NOT NULL DEFAULT '0',
  `role_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`,`testproject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_testproject_roles`
--

LOCK TABLES `user_testproject_roles` WRITE;
/*!40000 ALTER TABLE `user_testproject_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_testproject_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first` varchar(30) NOT NULL DEFAULT '',
  `last` varchar(30) NOT NULL DEFAULT '',
  `locale` varchar(10) NOT NULL DEFAULT 'en_GB',
  `default_testproject_id` int(10) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `script_key` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='User information';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','aaaf2dea0fd20fe54429dfab68533cd6',8,'admin@gizur.com','Testlink','Administrator','en_GB',NULL,1,NULL),(2,'jonas','422d2556dd9d192869d2925c22a2657d',8,'jonas.colmsjo@gizur.com','Jonas','Colmsjö','en_GB',NULL,1,NULL),(3,'devasis','edef167c83cac57330b9cda364194c5e',8,'d.roy@essindia.co.in','Devasis','Roy','en_GB',NULL,1,NULL),(4,'ashish','cf36c1debc016e407ae44ce1fdc23e45',8,'ashish-purwar@essindia.co.in','ashish','purwar','en_GB',NULL,1,NULL),(5,'akumar','6edff95dabd2b7ed2311e60d6f4f6310',8,'gizur-ess-anshuk@gizur.com','Anschuk','Kumar','en_GB',NULL,1,NULL),(6,'pankaj','e8f7eff493d7795168dc39b168906a7a',8,'pankaj.hotwani@gslab.com','Pankaj','Hotwani','en_GB',NULL,1,NULL),(7,'gizur-ess-prabhat','96b592a2f80b27faa0f40bd30de6136b',8,'gizur-ess-prabhat@gizur.com','Prabhat','Khera','en_GB',NULL,1,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-01-07 13:59:46
